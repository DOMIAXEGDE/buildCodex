# Documentation Bundle

- **Root:** `C:\Users\dacoo\OneDrive\buildHeaven`
- **Generated:** `2026-02-25T01:57:56`
- **Included files:** `23`
- **Max text file bytes:** `5000000`
- **Ignored dirs:** `.git, .hg, .idea, .svn, .venv, .vscode, __pycache__, build, dist, doc, node_modules, vendor, venv`

## Filesystem Tree (included paths)

```text
buildHeaven
├── A-0_System.txt
├── A_plus.txt
├── A_plus_plus.txt
├── A_sharp_axiom.txt
├── A_sharp_dot-NET.txt
├── ABAP.txt
├── ABC.txt
├── ABC_ALGOL.txt
├── Accent.txt
├── Ace_DASL.txt
├── Ada.txt
├── assembly.txt
├── bundle_documentation.py
├── C.txt
├── cpp.txt
├── D.txt
├── Fortran.txt
├── Nim.txt
├── Objective-C.txt
├── Pascal.txt
├── Rust.txt
├── Swift.txt
└── Zig.txt
```

## Table of Contents

1. [`A-0_System.txt`](#file-1)
2. [`A_plus.txt`](#file-2)
3. [`A_plus_plus.txt`](#file-3)
4. [`A_sharp_axiom.txt`](#file-4)
5. [`A_sharp_dot-NET.txt`](#file-5)
6. [`ABAP.txt`](#file-6)
7. [`ABC.txt`](#file-7)
8. [`ABC_ALGOL.txt`](#file-8)
9. [`Accent.txt`](#file-9)
10. [`Ace_DASL.txt`](#file-10)
11. [`Ada.txt`](#file-11)
12. [`assembly.txt`](#file-12)
13. [`bundle_documentation.py`](#file-13)
14. [`C.txt`](#file-14)
15. [`cpp.txt`](#file-15)
16. [`D.txt`](#file-16)
17. [`Fortran.txt`](#file-17)
18. [`Nim.txt`](#file-18)
19. [`Objective-C.txt`](#file-19)
20. [`Pascal.txt`](#file-20)
21. [`Rust.txt`](#file-21)
22. [`Swift.txt`](#file-22)
23. [`Zig.txt`](#file-23)

## File Contents

<a id="file-1"></a>
### [1] `A-0_System.txt`

- **Bytes:** `6069`
- **Type:** `text`

```text
; =================================:contentReference[oaicite:4]{index=4}======
; A-0 SYSTEM SCRIPT (monolithic): SYSTEM_SAFE_GENERATOR.A0
; ============================================================
; Program intent (from attached assembly):
;   - Open "system_safe.txt" for writing
;   - Enumerate all base-64 strings of length N=4 using a 64-char alphabet
;   - Write each string + newline
;   - Close file, return status
;
; Alphabet (64 chars):
;   "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \n"
; ============================================================

; -------------------------
; DATA DECK (literals)
; -------------------------
D0001: ASCII "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \n"   ; 64 chars
D0002: ASCII "system_safe.txt"
D0003: ASCII "w"
D0004: ASCII "Error opening file"
D0005: U64   4                                                         ; N = 4
D0006: U64   64                                                        ; BASE = 64
D0007: U64   63                                                        ; MASK = 0x3F
D0008: U8    10                                                        ; '\n'

; -------------------------
; RESERVED STORAGE (variables)
; -------------------------
V0001: PTR   0              ; FILE_HANDLE
V0002: U64   0              ; LIMIT = 64^N
V0003: U64   0              ; I (outer counter)
V0004: U64   0              ; X (scratch copy of I)
V0005: S64   0              ; J (signed index, counts down)
V0006: U64   0              ; DIGIT (0..63)
V0007: U8    0              ; CH
V0010: BYTES 64             ; BUF (we only use first N bytes)

; -------------------------
; SUBROUTINE DIRECTORY (numeric “call numbers”)
; -------------------------
;   ID    NAME                         ARGS...                         -> RET
; ---------------------------------------------------------------
;   010   U64_SAFE_POW                 (base, exp, out_u64_ptr)         -> ok(0/1)
;   020   GEN_PERMUTATIONS             (n, alphabet_ptr, file_handle)   -> ok(0/1)
;   500   FOPEN                        (filename_ptr, mode_ptr)         -> file_handle(0 if fail)
;   501   FCLOSE                       (file_handle)                    -> ok(0/1)
;   502   FWRITE_ALL                   (file_handle, buf_ptr, len_u64)  -> ok(0/1)
;   503   FPUTC_SAFE                   (file_handle, u8_char)           -> ok(0/1)
;   510   UMUL_OVF                     (a_u64, b_u64)                   -> (prod_u64, ovf_u8)
;   520   PERROR                       (msg_ptr)                        -> ()
;   999   EXIT                         (code_u64)                       -> ()
;
; (500..503,520,999 are “environment/library” routines in A-0 spirit.)

; ============================================================
; SUBROUTINE 010: U64_SAFE_POW(base, exp, out_ptr) -> ok
; Mirrors: safe_uint64_power() in the assembly
; ============================================================
SUB 010 U64_SAFE_POW
    ; out = 1
    STORE_U64 [ARG3], 1
    STORE_U64 V0003, 0                ; reuse V0003 as local COUNTER

L010_00:
    ; if COUNTER >= EXP: return 1
    IF_U64_GE  V0003, ARG2  GOTO L010_OK

    ; (prod, ovf) = UMUL_OVF(*out, base)
    LOAD_U64   V0004, [ARG3]
    CALL 510   V0004, ARG1      -> V0002, V0007   ; prod -> V0002, ovf -> V0007

    ; if ovf != 0: return 0
    IF_U8_NE   V0007, 0         GOTO L010_FAIL

    ; *out = prod
    STORE_U64  [ARG3], V0002

    ; COUNTER++
    ADD_U64    V0003, V0003, 1
    GOTO L010_00

L010_FAIL:
    RETURN_U8  0

L010_OK:
    RETURN_U8  1
ENDSUB


; ============================================================
; SUBROUTINE 020: GEN_PERMUTATIONS(n, alphabet_ptr, file_handle) -> ok
; Mirrors: generate_permutations() in the assembly
; ============================================================
SUB 020 GEN_PERMUTATIONS
    ; compute LIMIT = 64^n safely
    CALL 010  D0006, ARG1, &V0002   -> V0007      ; ok in V0007
    IF_U8_EQ  V0007, 0              GOTO L020_FAIL

    ; i = 0
    STORE_U64 V0003, 0

L020_I_LOOP:
    ; if i >= LIMIT: return 1
    IF_U64_GE V0003, V0002          GOTO L020_OK

    ; x = i
    STORE_U64 V0004, V0003

    ; j = n - 1  (signed)
    SUB_S64   V0005, ARG1, 1

L020_J_LOOP:
    ; if j < 0: finished digits
    IF_S64_LT V0005, 0              GOTO L020_WRITE

    ; digit = x & 63
    AND_U64   V0006, V0004, D0007

    ; ch = alphabet[digit]
    LOAD_U8_INDEX  V0007, ARG2, V0006    ; V0007 = *(alphabet + digit)

    ; BUF[j] = ch
    STORE_U8_INDEX V0010, V0005, V0007   ; *(BUF + j) = ch

    ; x >>= 6
    SHR_U64   V0004, V0004, 6

    ; j--
    SUB_S64   V0005, V0005, 1
    GOTO L020_J_LOOP

L020_WRITE:
    ; write BUF[0..n-1]
    CALL 502  ARG3, &V0010, ARG1    -> V0007
    IF_U8_EQ  V0007, 0              GOTO L020_FAIL

    ; write '\n'
    CALL 503  ARG3, D0008           -> V0007
    IF_U8_EQ  V0007, 0              GOTO L020_FAIL

    ; i++
    ADD_U64   V0003, V0003, 1
    GOTO L020_I_LOOP

L020_FAIL:
    RETURN_U8 0

L020_OK:
    RETURN_U8 1
ENDSUB


; ============================================================
; MAIN PROGRAM DECK (A-0 “sequence of subroutines + arguments”)
; Mirrors: main() in the assembly
; ============================================================
MAIN:
    ; file = fopen("system_safe.txt", "w")
    CALL 500  D0002, D0003              -> V0001

    ; if file == 0: perror("Error opening file"); exit(1)
    IF_PTR_EQ V0001, 0                  GOTO M_OPEN_FAIL

    ; ok = GEN_PERMUTATIONS(N, ALPHABET, file)
    CALL 020  D0005, D0001, V0001       -> V0007

    ; close file (best-effort)
    CALL 501  V0001                     -> V0006

    ; if ok == 0: exit(1) else exit(0)
    IF_U8_EQ  V0007, 0                  GOTO M_EXIT_FAIL
    CALL 999  0
    HALT

M_OPEN_FAIL:
    CALL 520  D0004
    CALL 999  1
    HALT

M_EXIT_FAIL:
    CALL 999  1
    HALT
ENDMAIN

```

<a id="file-2"></a>
### [2] `A_plus.txt`

- **Bytes:** `7804`
- **Type:** `text`

```text
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; A+ MONOLITHIC SCRIPT
;; Name: system_safe_generator.aplus
;; Source: assembly.txt  (safe_uint64_power, generate_permutations, file sink, main)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

A+::UNIT "system_safe_generator"
A+::VERSION 1.0

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Primitive Types
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

TYPE u8   = UINT(8)
TYPE u32  = UINT(32)
TYPE u64  = UINT(64)
TYPE u128 = UINT(128)
TYPE i32  = SINT(32)
TYPE i64  = SINT(64)
TYPE bool = ENUM { false=0, true=1 }

TYPE ptr[T] = POINTER(T)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Minimal OS / C-ABI Surface (conceptual intrinsics)
;; (A+ runtimes typically provide equivalents; keep names stable for clarity.)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

TYPE FileHandle = ptr[opaque]

INTRINSIC OS.fopen(path: ptr[u8], mode: ptr[u8]) -> FileHandle
INTRINSIC OS.fwrite(buf: ptr[u8], size: u64, count: u64, fh: FileHandle) -> u64
INTRINSIC OS.fputc(ch: i32, fh: FileHandle) -> i32
INTRINSIC OS.fclose(fh: FileHandle) -> i32
INTRINSIC OS.perror(msg: ptr[u8]) -> void

INTRINSIC MEM.zero(buf: ptr[u8], n: u64) -> void

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Constants (matches assembly .ascii/.string payloads)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

CONST ALPHABET_STR : BYTES =
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \n"
;; Length must be exactly 64:
;; 26 lower + 26 upper + 10 digits + space + '\n' = 64.

CONST MODE_WRITE : BYTES = "w"
CONST OUT_PATH   : BYTES = "system_safe.txt"
CONST ERR_OPEN   : BYTES = "Error opening file"

CONST U64_MAX : u128 = 18446744073709551615  ;; 2^64 - 1

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; OutputSink (layout mirrors the idea in assembly: ctx + function pointers)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

STRUCT OutputSink {
    ctx        : FileHandle
    write      : fn(ctx: FileHandle, data: ptr[u8], n: u64) -> bool
    write_char : fn(ctx: FileHandle, ch: u8) -> bool
}

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Helpers: safe u64 multiply (models x86 MUL overflow test)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

FN safe_mul_u64(a: u64, b: u64, out: ref u64) -> bool
{
    LET prod : u128 = (u128)a * (u128)b
    IF prod > U64_MAX THEN
        RETURN false
    ENDIF
    out = (u64)prod
    RETURN true
}

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; safe_uint64_power(base, exp, out*) -> bool
;; Assembly behavior:
;;   *out = 1
;;   repeat exp times: if overflow return 0 else *out *= base
;;   return 1 on success
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

FN safe_uint64_power(base: u64, exp: u64, out: ref u64) -> bool
{
    out = 1
    LET i : u64 = 0

    WHILE i < exp DO
        LET tmp : u64 = out
        IF NOT safe_mul_u64(tmp, base, out) THEN
            RETURN false
        ENDIF
        i = i + 1
    ENDWHILE

    RETURN true
}

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; file_sink_write(ctx, data, n) -> bool
;; Assembly uses fwrite(data, 1, n, FILE*) and checks written == n
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

FN file_sink_write(ctx: FileHandle, data: ptr[u8], n: u64) -> bool
{
    LET written : u64 = OS.fwrite(data, 1, n, ctx)
    RETURN (written == n)
}

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; file_sink_write_char(ctx, ch) -> bool
;; Assembly uses fputc(ch, FILE*) and checks != -1
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

FN file_sink_write_char(ctx: FileHandle, ch: u8) -> bool
{
    LET rc : i32 = OS.fputc((i32)ch, ctx)
    RETURN (rc != -1)
}

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; file_sink_init(sink*, path) -> bool
;; Assembly: fopen(path,"w"); on success sets sink.ctx and fn pointers
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

FN file_sink_init(sink: ref OutputSink, path: BYTES) -> bool
{
    LET fh : FileHandle = OS.fopen(&path[0], &MODE_WRITE[0])
    IF fh == NULL THEN
        RETURN false
    ENDIF

    sink.ctx        = fh
    sink.write      = file_sink_write
    sink.write_char = file_sink_write_char
    RETURN true
}

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; file_sink_close(sink*) -> void
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

FN file_sink_close(sink: ref OutputSink) -> void
{
    IF sink.ctx != NULL THEN
        OS.fclose(sink.ctx)
        sink.ctx = NULL
    ENDIF
}

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; generate_permutations(n, sink*) -> bool
;; Assembly behavior:
;;   total = 64^n  (checked with safe_uint64_power)
;;   for i in [0, total):
;;     tmp = i
;;     idx = n-1 down to 0:
;;       digit = tmp & 63
;;       buf[idx] = ALPHABET[digit]
;;       tmp >>= 6
;;     sink.write(buf, n) must succeed
;;     sink.write_char(10) must succeed
;;   return 1 on full success else 0
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

FN generate_permutations(n: u64, sink: ref OutputSink) -> bool
{
    ;; total permutations: 64^n
    LET total : u64 = 0
    IF NOT safe_uint64_power(64, n, total) THEN
        RETURN false
    ENDIF

    ;; buffer (monolithic, fixed upper bound; we only use first n bytes)
    ;; assembly uses a small stack buffer; here we cap at 64 for safety.
    IF n > 64 THEN
        RETURN false
    ENDIF

    LET buf : ARRAY[u8, 64]
    MEM.zero(&buf[0], 64)

    LET i : u64 = 0
    WHILE i < total DO
        LET tmp : u64 = i
        LET idx : i64 = (i64)n - 1

        WHILE idx >= 0 DO
            LET digit : u64 = tmp & 63
            buf[(u64)idx] = (u8)ALPHABET_STR[digit]
            tmp = tmp >> 6
            idx = idx - 1
        ENDWHILE

        ;; write n bytes
        IF NOT sink.write(sink.ctx, &buf[0], n) THEN
            RETURN false
        ENDIF

        ;; then write '\n' (LF = 10), matching assembly
        IF NOT sink.write_char(sink.ctx, (u8)10) THEN
            RETURN false
        ENDIF

        i = i + 1
    ENDWHILE

    RETURN true
}

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; main
;; Assembly:
;;   n = 4
;;   init sink("system_safe.txt") else perror("Error opening file") and exit 1
;;   ok = generate_permutations(4, &sink)
;;   close sink
;;   return 0 if ok else 1
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

FN main() -> i32
{
    LET n : u64 = 4

    LET sink : OutputSink
    sink.ctx        = NULL
    sink.write      = file_sink_write
    sink.write_char = file_sink_write_char

    IF NOT file_sink_init(sink, OUT_PATH) THEN
        OS.perror(&ERR_OPEN[0])
        RETURN 1
    ENDIF

    LET ok : bool = generate_permutations(n, sink)

    file_sink_close(sink)

    IF NOT ok THEN
        RETURN 1
    ENDIF

    RETURN 0
}

A+::ENTRY main

```

<a id="file-3"></a>
### [3] `A_plus_plus.txt`

- **Bytes:** `6608`
- **Type:** `text`

```text
/*
  =====================================================================
  A++ Monolith: system_safe_permutations.a++
  =====================================================================

  Source-equivalent translation of assembly.txt. :contentReference[oaicite:1]{index=1}

  What it does:
    - ALPHABET is 64 symbols: a-z A-Z 0-9 ' ' '\n'
    - For n = 4 (main), enumerates all 64^n codes.
    - Each code is written as raw bytes (NOT NUL-terminated), then a '\n'.
    - NOTE: because '\n' is itself a symbol in ALPHABET, some generated
      codes contain newline bytes *inside* the code, which will visually
      break lines in the output file (this matches the assembly behavior).

  Output size for n=4:
    - 64^4 = 16,777,216 records (huge).
*/

/* =========================
   A++: Core scalar types
   ========================= */

type  U8   = unsigned_8;
type  U32  = unsigned_32;
type  U64  = unsigned_64;
type  U128 = unsigned_128;
type  I32  = signed_32;
type  Bool = unsigned_8;   // 0 or 1

const Bool FALSE = 0;
const Bool TRUE  = 1;

const U64 U64_MAX = 18446744073709551615;

/* =========================
   A++: Minimal FFI surface
   =========================
   These are abstract bindings to the host C runtime.
*/

opaque type FILE;

/* C stdio bindings */
extern func fopen(path: ptr<const U8>, mode: ptr<const U8>) -> ptr<FILE>;
extern func fclose(f: ptr<FILE>) -> I32;
extern func fwrite(buf: ptr<const U8>, size: U64, count: U64, f: ptr<FILE>) -> U64;
extern func fputc(ch: I32, f: ptr<FILE>) -> I32;
extern func perror(msg: ptr<const U8>) -> void;

/* =========================
   A++: Memory helpers
   ========================= */

extern func malloc(n: U64) -> ptr<U8>;
extern func free(p: ptr<U8>) -> void;

/* =========================
   A++: OutputSink interface
   ========================= */

type WriteFn     = func(ctx: ptr<void>, buf: ptr<const U8>, len: U64) -> Bool;
type WriteCharFn = func(ctx: ptr<void>, ch: U8) -> Bool;

struct OutputSink {
  ctx: ptr<void>;
  write: WriteFn;
  write_char: WriteCharFn;
}

/* =========================
   Embedded Alphabet (64 bytes)
   Matches:
     "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ01234567"
     "89 \n"
   ========================= */

const U8 ALPHABET[64] = [
  'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
  'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
  '0','1','2','3','4','5','6','7','8','9',' ','\n'
];

/* =========================
   Safe arithmetic
   ========================= */

func u64_mul_overflow(a: U64, b: U64, out: ptr<U64>) -> Bool {
  // Implements the same intent as the assembly's MUL + overflow flag test.
  // Here, we use a widened multiplication and compare against U64_MAX.
  let wide: U128 = (U128)a * (U128)b;
  if wide > (U128)U64_MAX {
    return TRUE;  // overflow occurred
  }
  *out = (U64)wide;
  return FALSE;   // no overflow
}

/*
  safe_uint64_power(base, exp, out):
    out := base^exp, returning TRUE on success, FALSE on overflow.
  This matches the assembly routine that multiplies exp times, checking overflow.
*/
func safe_uint64_power(base: U64, exp: U64, out: ptr<U64>) -> Bool {
  *out = 1;
  let i: U64 = 0;

  while i < exp {
    let tmp: U64 = 0;
    let ov: Bool = u64_mul_overflow(*out, base, &tmp);
    if ov == TRUE {
      return FALSE;
    }
    *out = tmp;
    i = i + 1;
  }

  return TRUE;
}

/* =========================
   File sink implementation
   ========================= */

func file_sink_write(ctx: ptr<void>, buf: ptr<const U8>, len: U64) -> Bool {
  let f: ptr<FILE> = (ptr<FILE>)ctx;

  // fwrite(buf, 1, len, f) must return len to succeed.
  let wrote: U64 = fwrite(buf, 1, len, f);
  if wrote == len { return TRUE; }
  return FALSE;
}

func file_sink_write_char(ctx: ptr<void>, ch: U8) -> Bool {
  let f: ptr<FILE> = (ptr<FILE>)ctx;

  // fputc returns -1 on error.
  let rc: I32 = fputc((I32)ch, f);
  if rc != -1 { return TRUE; }
  return FALSE;
}

func file_sink_init(sink: ptr<OutputSink>, path: ptr<const U8>) -> Bool {
  const U8 MODE_W[2] = ['w', 0];

  let f: ptr<FILE> = fopen(path, &MODE_W[0]);
  if f == (ptr<FILE>)0 {
    return FALSE;
  }

  sink->ctx = (ptr<void>)f;
  sink->write = file_sink_write;
  sink->write_char = file_sink_write_char;
  return TRUE;
}

func file_sink_close(sink: ptr<OutputSink>) -> void {
  if sink == (ptr<OutputSink>)0 { return; }
  if sink->ctx == (ptr<void>)0 { return; }

  let f: ptr<FILE> = (ptr<FILE>)sink->ctx;
  fclose(f);
  sink->ctx = (ptr<void>)0;
}

/* =========================
   Permutation generator
   =========================
   generate_permutations(n, sink):
     total = 64^n
     for i in [0..total-1]:
       encode i in base64 digits (6-bit chunks) into n bytes:
         idx = (tmp & 63)
         tmp >>= 6
       write n bytes then '\n'
*/

func generate_permutations(n: U64, sink: ptr<OutputSink>) -> Bool {
  let total: U64 = 0;

  if safe_uint64_power(64, n, &total) == FALSE {
    return FALSE;
  }

  // Allocate exactly n bytes (no NUL terminator), matching fwrite usage.
  let buf: ptr<U8> = malloc(n);
  if buf == (ptr<U8>)0 {
    return FALSE;
  }

  let i: U64 = 0;
  while i < total {

    let tmp: U64 = i;

    // Fill from end to start: pos = n-1 down to 0
    // Matches the assembly decrementing an index and writing into [rbp-50 + pos].
    let pos: I32 = (I32)(n - 1);

    while pos >= 0 {
      let idx: U64 = (tmp & 63);
      buf[(U64)pos] = ALPHABET[idx];
      tmp = (tmp >> 6);
      pos = pos - 1;
    }

    if sink->write(sink->ctx, buf, n) == FALSE {
      free(buf);
      return FALSE;
    }

    if sink->write_char(sink->ctx, (U8)10) == FALSE { // '\n'
      free(buf);
      return FALSE;
    }

    i = i + 1;
  }

  free(buf);
  return TRUE;
}

/* =========================
   Program entrypoint
   ========================= */

func main() -> I32 {
  const U8 OUT_PATH[] = "system_safe.txt\0";
  const U8 ERR_MSG[]  = "Error opening file\0";

  let sink: OutputSink;

  // In the assembly, n is set to 4.
  let n: U64 = 4;

  if file_sink_init(&sink, &OUT_PATH[0]) == FALSE {
    perror(&ERR_MSG[0]);
    return 1;
  }

  let ok: Bool = generate_permutations(n, &sink);

  file_sink_close(&sink);

  if ok == TRUE { return 0; }
  return 1;
}

```

<a id="file-4"></a>
### [4] `A_sharp_axiom.txt`

- **Bytes:** `6280`
- **Type:** `text`

```text
// A# (Axiom) Monolithic Script (C#-compatible .NET single-file)
// ------------------------------------------------------------
// Behavior matches the attached program:
// - ALPHABET: 64 chars: a-z A-Z 0-9 space newline
// - safe_uint64_power(64, n, &outTotal) with overflow detection
// - generate_permutations(n, sink): for i in [0, 64^n):
//     build n bytes by repeated: digit = tmp & 63; tmp >>= 6
//     store into buffer from right-to-left (pos = n-1..0)
//     sink.write(buffer, n); sink.write_char('\n')
// - main: n=4, output file "system_safe.txt"
//
// Notes:
// - This intentionally writes LF '\n' (byte 10) as in the assembly, not CRLF.
// - Because ALPHABET includes '\n', some generated “strings” contain newlines inside them
//   exactly like the original program, producing additional line breaks in the output.

using System;
using System.IO;
using System.Text;

public static class AxiomProgram
{
    // 64-character alphabet (matches the assembly exactly):
    // "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \n"
    private static readonly byte[] ALPHABET = Encoding.ASCII.GetBytes(
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \n"
    );

    // OutputSink equivalent: ctx + function pointers (modeled as virtual methods here).
    private abstract class OutputSink : IDisposable
    {
        public abstract bool Write(ReadOnlySpan<byte> data);
        public abstract bool WriteChar(byte c);
        public abstract void Dispose();
    }

    // File-backed sink (fopen/fwrite/fputc/fclose analog).
    private sealed class FileSink : OutputSink
    {
        private FileStream? _fs;

        public static bool Init(out FileSink sink, string path)
        {
            sink = new FileSink();
            try
            {
                // "w" mode equivalent (truncate/create).
                sink._fs = new FileStream(
                    path,
                    FileMode.Create,
                    FileAccess.Write,
                    FileShare.Read,
                    bufferSize: 1 << 20, // 1 MiB buffer for throughput
                    useAsync: false
                );
                return true;
            }
            catch
            {
                sink.Dispose();
                return false;
            }
        }

        public override bool Write(ReadOnlySpan<byte> data)
        {
            try
            {
                if (_fs is null) return false;
                _fs.Write(data);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public override bool WriteChar(byte c)
        {
            try
            {
                if (_fs is null) return false;
                _fs.WriteByte(c);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public override void Dispose()
        {
            try { _fs?.Dispose(); } catch { /* swallow */ }
            _fs = null;
        }
    }

    // safe_uint64_power(unsigned long base, unsigned long exp, unsigned long* out)
    // Returns: true on success, false on overflow (matches assembly: eax=1 success, eax=0 fail).
    private static bool SafeUInt64Power(ulong @base, ulong exp, out ulong result)
    {
        result = 1UL;

        // exp loop like the assembly (i from 0 while i<exp).
        for (ulong i = 0; i < exp; i++)
        {
            // Detect overflow for result *= base
            // (unsigned multiply overflow check).
            if (@base != 0 && result > (ulong.MaxValue / @base))
                return false;

            result *= @base;
        }

        return true;
    }

    // generate_permutations(unsigned long n, OutputSink* sink)
    // Returns: true on success, false if sink write fails or overflow in power.
    private static bool GeneratePermutations(ulong n, OutputSink sink)
    {
        // total = 64^n (safe)
        if (!SafeUInt64Power(64UL, n, out ulong total))
            return false;

        // Buffer corresponds to the stack buffer used in the assembly.
        // We write exactly n bytes to sink, then a '\n' char via WriteChar(10).
        // Use a fixed byte[] for speed; fill per iteration.
        if (n > int.MaxValue) return false; // sanity (won't happen here)
        int len = (int)n;
        byte[] buf = new byte[len];

        for (ulong i = 0; i < total; i++)
        {
            ulong tmp = i;
            long pos = len - 1; // assembly: starts at n-1 and decrements to 0

            while (pos >= 0)
            {
                // digit = tmp & 63
                int digit = (int)(tmp & 63UL);
                buf[pos] = ALPHABET[digit];

                // tmp >>= 6
                tmp >>= 6;

                pos--;
            }

            // sink.write(ctx, buf, n)
            if (!sink.Write(buf))
                return false;

            // sink.write_char(ctx, 10)
            if (!sink.WriteChar((byte)10))
                return false;
        }

        return true;
    }

    // main (matches the assembly’s behavior):
    // - output path: "system_safe.txt"
    // - n = 4
    public static int Main(string[] args)
    {
        const string defaultPath = "system_safe.txt";
        const ulong defaultN = 4;

        // Allow optional overrides (still monolithic; defaults match original):
        // args[0] = output path, args[1] = n
        string path = (args.Length >= 1 && !string.IsNullOrWhiteSpace(args[0])) ? args[0] : defaultPath;
        ulong n = defaultN;

        if (args.Length >= 2 && ulong.TryParse(args[1], out ulong parsed))
            n = parsed;

        if (!FileSink.Init(out FileSink sink, path))
        {
            Console.Error.WriteLine("Error opening file");
            return 1;
        }

        bool ok;
        try
        {
            ok = GeneratePermutations(n, sink);
        }
        finally
        {
            sink.Dispose();
        }

        return ok ? 0 : 1;
    }
}

```

<a id="file-5"></a>
### [5] `A_sharp_dot-NET.txt`

- **Bytes:** `6119`
- **Type:** `text`

```text
--  system_safe.adb
--  Monolithic A# (.NET) / Ada program equivalent to the provided assembly.
--  Writes all base-64 “digits” (using the given 64-char alphabet) for length N
--  into "system_safe.txt", one permutation per line.

with Ada.Characters.Latin_1;
with Ada.Command_Line;
with Ada.Text_IO;
with Ada.Streams;
with Ada.Streams.Stream_IO;
with Interfaces;

procedure System_Safe is
   use Interfaces;
   use Ada.Characters.Latin_1;

   -- ALPHABET:
   -- "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \n"
   Alphabet : constant String :=
     "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 " & LF;

   Default_Out_Path : constant String := "system_safe.txt";
   Err_Open_Msg     : constant String := "Error opening file";

   type Output_Sink is record
      File    : Ada.Streams.Stream_IO.File_Type;
      Is_Open : Boolean := False;
   end record;

   function File_Sink_Init (Sink : in out Output_Sink; Path : String) return Boolean is
   begin
      Ada.Streams.Stream_IO.Create
        (File => Sink.File,
         Mode => Ada.Streams.Stream_IO.Out_File,
         Name => Path);
      Sink.Is_Open := True;
      return True;
   exception
      when others =>
         Sink.Is_Open := False;
         return False;
   end File_Sink_Init;

   procedure File_Sink_Close (Sink : in out Output_Sink) is
   begin
      if Sink.Is_Open then
         Ada.Streams.Stream_IO.Close (Sink.File);
         Sink.Is_Open := False;
      end if;
   exception
      when others =>
         null;
   end File_Sink_Close;

   function File_Sink_Write (Sink : in out Output_Sink; Data : String) return Boolean is
      use Ada.Streams;
      use Ada.Streams.Stream_IO;
      Buf : Stream_Element_Array (1 .. Stream_Element_Offset (Data'Length));
      J   : Stream_Element_Offset := 1;
   begin
      if not Sink.Is_Open then
         return False;
      end if;

      for I in Data'Range loop
         Buf (J) := Stream_Element (Character'Pos (Data (I)));
         J := J + 1;
      end loop;

      Write (Sink.File, Buf);
      return True;
   exception
      when others =>
         return False;
   end File_Sink_Write;

   function File_Sink_Write_Char (Sink : in out Output_Sink; C : Character) return Boolean is
      use Ada.Streams;
      use Ada.Streams.Stream_IO;
      Buf : Stream_Element_Array (1 .. 1);
   begin
      if not Sink.Is_Open then
         return False;
      end if;

      Buf (1) := Stream_Element (Character'Pos (C));
      Write (Sink.File, Buf);
      return True;
   exception
      when others =>
         return False;
   end File_Sink_Write_Char;

   -- safe_uint64_power(base, exp, *out) -> Boolean success (no overflow)
   function Safe_Uint64_Power
     (Base   : Unsigned_64;
      Exp    : Unsigned_64;
      Result : out Unsigned_64) return Boolean
   is
      R : Unsigned_64 := 1;
      I : Unsigned_64 := 0;
   begin
      Result := 1;

      while I < Exp loop
         if Base = 0 then
            R := 0;
         else
            -- overflow check: R * Base must fit in Unsigned_64
            if R > Unsigned_64'Last / Base then
               Result := 0;
               return False;
            end if;
            R := R * Base;
         end if;

         I := I + 1;
      end loop;

      Result := R;
      return True;
   end Safe_Uint64_Power;

   -- generate_permutations(len, sink) -> Boolean
   function Generate_Permutations
     (Len  : Natural;
      Sink : in out Output_Sink) return Boolean
   is
      Total : Unsigned_64 := 0;
      I     : Unsigned_64 := 0;
   begin
      if not Safe_Uint64_Power (Base => 64, Exp => Unsigned_64 (Len), Result => Total) then
         return False;
      end if;

      if Len = 0 then
         -- Matches the assembly behavior: total = 1; write empty string + '\n'
         return File_Sink_Write_Char (Sink, LF);
      end if;

      declare
         Buffer : String (1 .. Len);
      begin
         while I < Total loop
            declare
               Tmp : Unsigned_64 := I;
            begin
               -- Fill from right to left: base-64 digits (Tmp & 63), then Tmp >>= 6
               for Pos in reverse Buffer'Range loop
                  declare
                     Idx : Natural := Natural (Tmp and 63); -- 0..63
                  begin
                     Buffer (Pos) := Alphabet (Alphabet'First + Idx);
                  end;
                  Tmp := Shift_Right (Tmp, 6);
               end loop;
            end;

            if not File_Sink_Write (Sink, Buffer) then
               return False;
            end if;

            if not File_Sink_Write_Char (Sink, LF) then
               return False;
            end if;

            I := I + 1;
         end loop;
      end;

      return True;
   end Generate_Permutations;

   -- main equivalents
   Sink     : Output_Sink;
   Len      : Natural := 4;
   Out_Path : String  := Default_Out_Path;
   Ok       : Boolean := False;

begin
   -- Optional CLI override:
   --   arg1 = length (Natural), arg2 = output path
   if Ada.Command_Line.Argument_Count >= 1 then
      declare
         use Ada.Text_IO;
      begin
         Len := Natural'Value (Ada.Command_Line.Argument (1));
      exception
         when others =>
            -- If parse fails, keep default
            null;
      end;
   end if;

   if Ada.Command_Line.Argument_Count >= 2 then
      Out_Path := Ada.Command_Line.Argument (2);
   end if;

   if not File_Sink_Init (Sink, Out_Path) then
      Ada.Text_IO.Put_Line (Ada.Text_IO.Standard_Error, Err_Open_Msg);
      Ada.Command_Line.Set_Exit_Status (Ada.Command_Line.Failure);
      return;
   end if;

   Ok := Generate_Permutations (Len, Sink);

   File_Sink_Close (Sink);

   if not Ok then
      Ada.Command_Line.Set_Exit_Status (Ada.Command_Line.Failure);
   else
      Ada.Command_Line.Set_Exit_Status (Ada.Command_Line.Success);
   end if;
end System_Safe;

```

<a id="file-6"></a>
### [6] `ABAP.txt`

- **Bytes:** `4345`
- **Type:** `text`

```text
REPORT z_system_safe_generate.

*----------------------------------------------------------------------
* Direct translation of assembly.txt :contentReference[oaicite:1]{index=1}
*
* ALPHABET (64 symbols):
*   "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ␊"
* where the final symbol is LF (0x0A).
*
* Generates all length-N words over this alphabet:
*   for i in [0 .. 64^N - 1]:
*     word[j] = ALPHABET[ (i >> (6*(N-1-j))) & 63 ]
*     write(word, N); write_char(10)
*
* ABAP notes:
* - OPEN DATASET writes to the *application server* filesystem.
* - Output is written in BINARY MODE to preserve embedded LF symbol.
* - Practical limit: N <= 10 (64^10 = 2^60 fits in signed INT8).
*----------------------------------------------------------------------

PARAMETERS:
  p_n    TYPE i      DEFAULT 4,
  p_file TYPE string LOWER CASE DEFAULT 'system_safe.txt'.

DATA:
  gv_alpha_str TYPE string,
  gv_alpha_x   TYPE xstring.

CONSTANTS:
  gc_base     TYPE i     VALUE 64,
  gc_lf_x     TYPE x     VALUE '0A',
  gc_int8_max TYPE int8  VALUE 9223372036854775807.

INITIALIZATION.
  " 26 lower + 26 upper + 10 digits + space + LF = 64 symbols
  gv_alpha_str = |abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 | &&
                 cl_abap_char_utilities=>newline.

  gv_alpha_x = cl_abap_conv_out_ce=>create(
                 encoding = 'UTF-8'
               )->convert( data = gv_alpha_str ).

START-OF-SELECTION.

  DATA(lv_limit) TYPE int8.
  IF p_n < 1 OR p_n > 10.
    WRITE: / |Error: p_n must be between 1 and 10 (requested { p_n }).|.
    RETURN.
  ENDIF.

  IF safe_pow_int8( iv_base = gc_base iv_exp = p_n CHANGING cv_pow = lv_limit ) = abap_false.
    WRITE: / |Error: overflow computing 64^{ p_n } within INT8 range.|.
    RETURN.
  ENDIF.

  OPEN DATASET p_file FOR OUTPUT IN BINARY MODE.
  IF sy-subrc <> 0.
    WRITE: / |Error opening file on application server: "{ p_file }" (sy-subrc={ sy-subrc }).|.
    RETURN.
  ENDIF.

  DATA(lv_ok) = generate_permutations_to_dataset( iv_n = p_n iv_limit = lv_limit iv_file = p_file ).

  CLOSE DATASET p_file.

  IF lv_ok = abap_true.
    WRITE: / |Done. Wrote 64^{ p_n } records to "{ p_file }" (binary).|.
  ELSE.
    WRITE: / |Stopped early due to a write error (sy-subrc={ sy-subrc }).|.
  ENDIF.

*----------------------------------------------------------------------
* safe_uint64_power equivalent (bounded to signed INT8 in ABAP)
*----------------------------------------------------------------------
FORM safe_pow_int8
  USING    iv_base TYPE i
           iv_exp  TYPE i
  CHANGING cv_pow  TYPE int8
  RETURNING VALUE(rv_ok) TYPE abap_bool.

  cv_pow = 1.
  rv_ok  = abap_true.

  DO iv_exp TIMES.
    " overflow check: cv_pow * iv_base <= gc_int8_max
    IF cv_pow > ( gc_int8_max DIV iv_base ).
      rv_ok = abap_false.
      EXIT.
    ENDIF.
    cv_pow = cv_pow * iv_base.
  ENDDO.
ENDFORM.

*----------------------------------------------------------------------
* generate_permutations equivalent: stream to OPEN DATASET (binary)
*----------------------------------------------------------------------
FORM generate_permutations_to_dataset
  USING    iv_n     TYPE i
           iv_limit TYPE int8
           iv_file  TYPE string
  RETURNING VALUE(rv_ok) TYPE abap_bool.

  rv_ok = abap_true.

  " Buffer (n bytes + 1 LF). Use a fixed X field then slice.
  DATA lv_buf   TYPE x LENGTH 1024.
  DATA lv_write TYPE xstring.

  DATA lv_i     TYPE int8 VALUE 0.
  DATA lv_temp  TYPE int8.
  DATA lv_pos   TYPE i.
  DATA lv_idx   TYPE i.
  DATA lv_len   TYPE i.

  lv_len = iv_n + 1.

  WHILE lv_i < iv_limit.

    CLEAR lv_buf.

    lv_temp = lv_i.
    lv_pos  = iv_n - 1.

    " Fill from right to left, base-64 digits (MOD/DIV by 64)
    WHILE lv_pos >= 0.
      lv_idx = lv_temp MOD gc_base.   " 0..63
      lv_buf+lv_pos(1) = gv_alpha_x+lv_idx(1).
      lv_temp = lv_temp DIV gc_base.
      lv_pos = lv_pos - 1.
    ENDWHILE.

    " Append LF (same as file_sink_write_char(..., 10))
    lv_buf+iv_n(1) = gc_lf_x.

    lv_write = lv_buf+0(lv_len).

    TRANSFER lv_write TO iv_file.
    IF sy-subrc <> 0.
      rv_ok = abap_false.
      EXIT.
    ENDIF.

    lv_i = lv_i + 1.
  ENDWHILE.

ENDFORM.

```

<a id="file-7"></a>
### [7] `ABC.txt`

- **Bytes:** `4586`
- **Type:** `text`

```text
# ======================================================================
# Monolithic ABC Script (single file)
# - Reconstructs behavior of assembly.txt program
# - Writes all 64^N permutations (N=4 in MAIN) to "system_safe.txt"
# ======================================================================

ABC_VERSION 1

# --- Constants ---------------------------------------------------------

CONST U64_MAX : u64 = 18446744073709551615

# 64-character alphabet (6-bit digits):
# 0..25  a-z
# 26..51 A-Z
# 52..61 0-9
# 62     space
# 63     newline
CONST ALPHABET : str =
  "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \n"

CONST OUT_PATH : str = "system_safe.txt"
CONST OPEN_MODE : str = "w"
CONST ERR_OPEN  : str = "Error opening file"

# --- Foreign / host-provided I/O --------------------------------------
# (ABC assumes these are provided by the runtime/host)

EXTERN FUNC fopen(path: str, mode: str) -> ptr
EXTERN FUNC fwrite(data: ptr, size: u64, count: u64, file: ptr) -> u64
EXTERN FUNC fputc(ch: i32, file: ptr) -> i32
EXTERN FUNC fclose(file: ptr) -> i32
EXTERN FUNC perror(msg: str) -> void

# --- Types -------------------------------------------------------------

TYPE WriteFn     = FUNC(ctx: ptr, data: ptr, n: u64) -> bool
TYPE WriteCharFn = FUNC(ctx: ptr, ch: u8) -> bool

STRUCT OutputSink {
  ctx       : ptr
  write     : WriteFn
  writeChar : WriteCharFn
}

# --- Helpers -----------------------------------------------------------

FUNC u64_mul_overflow(a: u64, b: u64, out: *u64) -> bool {
  # returns true if overflow would occur, else writes product and returns false
  IF a == 0 OR b == 0 {
    *out = 0
    RETURN false
  }
  IF a > (U64_MAX / b) {
    RETURN true
  }
  *out = a * b
  RETURN false
}

# safe_uint64_power(base, exp, outPtr) -> bool
# assembly semantics: initialize *out=1; loop exp times; if overflow -> return 0; else return 1
FUNC safe_uint64_power(base: u64, exp: u64, outPtr: *u64) -> bool {
  *outPtr = 1
  VAR i : u64 = 0

  WHILE i < exp {
    VAR prod : u64 = 0
    VAR ovf  : bool = u64_mul_overflow(*outPtr, base, &prod)
    IF ovf {
      RETURN false
    }
    *outPtr = prod
    i = i + 1
  }

  RETURN true
}

# --- File sink implementation -----------------------------------------

FUNC file_sink_write(ctx: ptr, data: ptr, n: u64) -> bool {
  # fwrite(data, 1, n, file) must equal n
  VAR wrote : u64 = fwrite(data, 1, n, ctx)
  RETURN (wrote == n)
}

FUNC file_sink_write_char(ctx: ptr, ch: u8) -> bool {
  VAR r : i32 = fputc((i32)ch, ctx)
  RETURN (r != -1)
}

FUNC file_sink_init(sink: *OutputSink, path: str) -> bool {
  VAR f : ptr = fopen(path, OPEN_MODE)
  IF f == 0 {
    RETURN false
  }

  sink->ctx       = f
  sink->write     = file_sink_write
  sink->writeChar = file_sink_write_char
  RETURN true
}

FUNC file_sink_close(sink: *OutputSink) -> void {
  IF sink == 0 { RETURN }
  IF sink->ctx == 0 { RETURN }

  fclose(sink->ctx)
  sink->ctx = 0
}

# --- Core logic --------------------------------------------------------

# generate_permutations(n, sink) -> bool
# Enumerates i from 0..(64^n - 1)
# For each i: fill buffer[n] from right-to-left using 6-bit digits and ALPHABET
# Then: sink.write(buffer,n); sink.writeChar('\n')
FUNC generate_permutations(n: u64, sink: *OutputSink) -> bool {
  VAR total : u64 = 0
  VAR okPow : bool = safe_uint64_power(64, n, &total)
  IF NOT okPow {
    RETURN false
  }

  VAR i : u64 = 0
  WHILE i < total {
    VAR x   : u64 = i
    VAR idx : i64 = (i64)n - 1

    # buffer sized to n bytes (no terminator needed; we write raw bytes)
    VAR buf : BYTES[n]

    WHILE idx >= 0 {
      VAR digit : u64 = (x & 63)                 # 6-bit chunk
      VAR ch    : u8  = (u8)ALPHABET[digit]      # lookup in 64-char alphabet
      buf[(u64)idx] = ch
      x = x >> 6
      idx = idx - 1
    }

    VAR okWrite : bool = sink->write(sink->ctx, &buf[0], n)
    IF NOT okWrite { RETURN false }

    VAR okNL : bool = sink->writeChar(sink->ctx, 10)  # '\n'
    IF NOT okNL { RETURN false }

    i = i + 1
  }

  RETURN true
}

# --- Program entry -----------------------------------------------------

FUNC MAIN() -> i32 {
  VAR sink : OutputSink

  VAR okInit : bool = file_sink_init(&sink, OUT_PATH)
  IF NOT okInit {
    perror(ERR_OPEN)
    RETURN 1
  }

  VAR okGen : bool = generate_permutations(4, &sink)

  file_sink_close(&sink)

  IF NOT okGen {
    RETURN 1
  }

  RETURN 0
}

```

<a id="file-8"></a>
### [8] `ABC_ALGOL.txt`

- **Bytes:** `4558`
- **Type:** `text`

```text
BEGIN
  COMMENT
    Monolithic ABC ALGOL (Algol-family) translation of assembly.txt.

    Behaviour (matches the assembly):
      - ALPHABET is 64 chars: a-z A-Z 0-9 space newline
      - safe_uint64_power(64, n, limit) returns FALSE if overflow would occur
      - generate_permutations(n, sink) enumerates i = 0 .. limit-1
        converts i to base-64 (6-bit chunks) into an n-char buffer
        writes buffer (n chars), then writes newline '\n' (ASCII 10)
      - main uses n = 4 and writes to "system_safe.txt"

    Notes:
      - Syntax here is an Algol-60-ish "ABC ALGOL" style with simple FILE I/O
        primitives (OPENWRITE / CLOSE / PUTCHAR / PUTSTRING). If your target
        ABC ALGOL dialect uses different I/O names, only those calls need
        renaming; the core logic is the same.
  ;

  COMMENT -------- Constants -------- ;

  STRING ALPHABET;
  ALPHABET := "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \n";

  LONG INTEGER UINT64_MAX;
  UINT64_MAX := 18446744073709551615;  COMMENT 2^64 - 1 ;

  COMMENT -------- Minimal OutputSink -------- ;

  RECORD OutputSink (FILE f);

  BOOLEAN PROCEDURE file_sink_init(sink, filename);
    VALUE filename; STRING filename;
    OutputSink sink;
  BEGIN
    FILE tmp;
    tmp := OPENWRITE(filename);             COMMENT open file for writing ;
    IF tmp = NIL THEN
      BEGIN
        file_sink_init := FALSE
      END
    ELSE
      BEGIN
        sink.f := tmp;
        file_sink_init := TRUE
      END
  END;

  PROCEDURE file_sink_close(sink);
    OutputSink sink;
  BEGIN
    IF sink.f <> NIL THEN
      BEGIN
        CLOSE(sink.f);
        sink.f := NIL
      END
  END;

  BOOLEAN PROCEDURE sink_write(sink, buf, len);
    OutputSink sink;
    VALUE len; INTEGER len;
    CHARACTER ARRAY buf;
  BEGIN
    INTEGER i;
    FOR i := 0 STEP 1 UNTIL len - 1 DO
      PUTCHAR(sink.f, buf[i]);
    sink_write := TRUE
  END;

  BOOLEAN PROCEDURE sink_write_char(sink, ch);
    OutputSink sink;
    VALUE ch; INTEGER ch;
  BEGIN
    PUTCHAR(sink.f, ch);
    sink_write_char := TRUE
  END;

  COMMENT -------- Safe uint64 power -------- ;

  BOOLEAN PROCEDURE safe_uint64_power(base, exp, out);
    VALUE base, exp; LONG INTEGER base, exp;
    LONG INTEGER out;
  BEGIN
    LONG INTEGER i;
    out := 1;

    FOR i := 1 STEP 1 UNTIL exp DO
      BEGIN
        COMMENT overflow check: out * base <= UINT64_MAX ;
        IF (base <> 0) AND (out > (UINT64_MAX DIV base)) THEN
          BEGIN
            safe_uint64_power := FALSE;
            GOTO done
          END;
        out := out * base
      END;

    safe_uint64_power := TRUE;

    done: ;
  END;

  COMMENT -------- Alphabet indexing helper -------- ;

  CHARACTER PROCEDURE alphabet_at(idx);
    VALUE idx; INTEGER idx;  COMMENT idx in 0..63 ;
  BEGIN
    COMMENT ALPHABET is treated as 1-based for SUB/CHAR extraction below ;
    alphabet_at := CHAR(ALPHABET, idx + 1)
  END;

  COMMENT -------- Generate permutations (actually all base-64 strings) -------- ;

  BOOLEAN PROCEDURE generate_permutations(n, sink);
    VALUE n; INTEGER n;
    OutputSink sink;
  BEGIN
    LONG INTEGER limit;
    LONG INTEGER i, tmp;
    INTEGER pos, digit;
    CHARACTER ARRAY buf[0:n-1];
    BOOLEAN ok;

    ok := safe_uint64_power(64, n, limit);
    IF NOT ok THEN
      BEGIN
        generate_permutations := FALSE;
        GOTO done
      END;

    FOR i := 0 STEP 1 UNTIL limit - 1 DO
      BEGIN
        tmp := i;

        FOR pos := n - 1 STEP -1 UNTIL 0 DO
          BEGIN
            digit := ENTIER(tmp MOD 64);        COMMENT low 6 bits ;
            buf[pos] := alphabet_at(digit);
            tmp := tmp DIV 64
          END;

        IF NOT sink_write(sink, buf, n) THEN
          BEGIN
            generate_permutations := FALSE;
            GOTO done
          END;

        IF NOT sink_write_char(sink, 10) THEN  COMMENT '\n' ;
          BEGIN
            generate_permutations := FALSE;
            GOTO done
          END
      END;

    generate_permutations := TRUE;

    done: ;
  END;

  COMMENT -------- main -------- ;

  OutputSink sink;
  BOOLEAN ok;

  ok := file_sink_init(sink, "system_safe.txt");
  IF NOT ok THEN
    BEGIN
      PUTSTRING(OUT, "Error opening file");
      PUTCHAR(OUT, 10);
      STOP(1)
    END;

  ok := generate_permutations(4, sink);
  file_sink_close(sink);

  IF NOT ok THEN STOP(1) ELSE STOP(0)

END

```

<a id="file-9"></a>
### [9] `Accent.txt`

- **Bytes:** `5866`
- **Type:** `text`

```text
// ============================================================================
// Accent Script (Monolithic)
// Program: system_safe permutation generator (64-ary, fixed length n=4)
// Source: assembly.txt translation (x86-64, Intel syntax)  :contentReference[oaicite:1]{index=1}
// ============================================================================
//
// Accent language conventions used here (self-contained / no imports):
// - Primitive types: u8, u64, i64, bool, ptr
// - Arrays: [T; N] for fixed-size; here we use stack arrays sized by n at runtime
// - "ref" parameters are mutable references
// - "extern" declares host-provided libc-like functions
// - Checked arithmetic helper: mul_u64_checked(a,b) -> (u64 product, bool overflow)
//
// NOTE: This emits 64^4 = 16,777,216 lines to system_safe.txt (very large).
// ============================================================================


// -------------------------------
// Host / libc-like externs
// -------------------------------
extern fn fopen(path: ptr<u8>, mode: ptr<u8>) -> ptr
extern fn fclose(f: ptr) -> i64
extern fn fwrite(buf: ptr<u8>, size: u64, count: u64, f: ptr) -> u64
extern fn fputc(ch: i64, f: ptr) -> i64
extern fn perror(msg: ptr<u8>) -> void

// Minimal helper to get C-string pointers from string literals
extern fn cstr(lit: string) -> ptr<u8>

// Checked multiply for u64 (returns overflow flag)
// (In a real Accent runtime this would map to MUL + OF/CF check.)
extern fn mul_u64_checked(a: u64, b: u64) -> (u64, bool)


// -------------------------------
// Constants (matches assembly)
// -------------------------------
const ALPHABET: string =
  "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ01234567" +
  "89 \n"   // includes: '8','9',' ','\n'  => total 64 chars

const MODE_W: string = "w"
const OUT_PATH: string = "system_safe.txt"
const ERR_OPEN: string = "Error opening file"


// -------------------------------
// OutputSink interface (matches the assembly's struct usage)
// sink.ctx is the "void*" in the assembly
// sink.write(ctx, buf, len) returns bool success
// sink.write_char(ctx, ch) returns bool success
// -------------------------------
struct OutputSink {
  ctx: ptr
  write: fn(ptr, ptr<u8>, u64) -> bool
  write_char: fn(ptr, u8) -> bool
}


// -------------------------------
// FileSink implementation
// -------------------------------

// file_sink_write(void*, char const*, unsigned long) -> bool
fn file_sink_write(ctx: ptr, buf: ptr<u8>, len: u64) -> bool {
  // fwrite(buf, 1, len, (FILE*)ctx) must write exactly len
  let written: u64 = fwrite(buf, 1, len, ctx)
  return written == len
}

// file_sink_write_char(void*, char) -> bool
fn file_sink_write_char(ctx: ptr, ch: u8) -> bool {
  // fputc returns -1 on error
  let rc: i64 = fputc(i64(ch), ctx)
  return rc != -1
}

// file_sink_init(OutputSink*, char const*) -> bool
fn file_sink_init(sink: ref OutputSink, path: string) -> bool {
  let f: ptr = fopen(cstr(path), cstr(MODE_W))
  if f == 0 {
    return false
  }
  sink.ctx = f
  sink.write = file_sink_write
  sink.write_char = file_sink_write_char
  return true
}

// file_sink_close(OutputSink*) -> void
fn file_sink_close(sink: ref OutputSink) -> void {
  if &sink == 0 { return }          // defensive
  if sink.ctx == 0 { return }
  _ = fclose(sink.ctx)
  sink.ctx = 0
}


// -------------------------------
// safe_uint64_power(base, exp, out*) -> bool
// Mirrors the assembly logic:
//   *out = 1; i = 0; while i < exp { if overflow(out*base) return false; out*=base; i++ }
// -------------------------------
fn safe_u64_power(base: u64, exp: u64, out: ref u64) -> bool {
  out = 1
  let i: u64 = 0
  while i < exp {
    let (p, overflow) = mul_u64_checked(out, base)
    if overflow { return false }
    out = p
    i = i + 1
  }
  return true
}


// -------------------------------
// generate_permutations(n, sink*) -> bool
// Matches the assembly algorithm:
// - limit = 64^n (checked)
// - for idx in [0..limit-1]:
//     x = idx
//     for pos from n-1 downto 0:
//        digit = x & 63
//        buf[pos] = ALPHABET[digit]
//        x >>= 6
//     sink.write(buf, n)
//     sink.write_char('\n')
// -------------------------------
fn generate_permutations(n: u64, sink: ref OutputSink) -> bool {
  let limit: u64 = 0
  if !safe_u64_power(64, n, limit) {
    return false
  }

  // runtime-sized stack buffer
  // Accent supports stack arrays sized by values (monolithic convenience)
  let buf: [u8; n]

  let idx: u64 = 0
  while idx < limit {
    let x: u64 = idx

    // Fill from right to left (pos = n-1 .. 0)
    // Assembly uses a signed loop with jns; same effect here.
    let pos_i: i64 = i64(n) - 1
    while pos_i >= 0 {
      let digit: u64 = x & 63
      buf[u64(pos_i)] = u8(ALPHABET[u64(digit)])
      x = x >> 6
      pos_i = pos_i - 1
    }

    // Write the n-byte string
    if !sink.write(sink.ctx, &buf[0], n) {
      return false
    }

    // Write newline char 10
    if !sink.write_char(sink.ctx, 10) {
      return false
    }

    idx = idx + 1
  }

  return true
}


// -------------------------------
// main (matches assembly):
// - n = 4
// - open "system_safe.txt" for write
// - on failure: perror("Error opening file"); return 1
// - generate_permutations(4, sink)
// - close
// - return 0 on success else 1
// -------------------------------
fn main() -> i64 {
  let n: u64 = 4

  let sink: OutputSink
  sink.ctx = 0
  sink.write = null
  sink.write_char = null

  if !file_sink_init(sink, OUT_PATH) {
    perror(cstr(ERR_OPEN))
    return 1
  }

  let ok: bool = generate_permutations(n, sink)

  file_sink_close(sink)

  if !ok { return 1 }
  return 0
}

```

<a id="file-10"></a>
### [10] `Ace_DASL.txt`

- **Bytes:** `4163`
- **Type:** `text`

```text
// SystemSafe_ace.dasl
// Monolithic "Ace DASL" script (BOS + AUS) corresponding to the assembly.txt program.
//
// Behavior: generate all BASE^len strings over ALPHABET by enumerating i=0..BASE^len-1,
// encoding i in base-64 using 6-bit digits (lowest digit on the right), and writing each
// len-byte record followed by '\n' to "system_safe.txt".

/* =========================
   DASL/BOS (Business Objects)
   ========================= */

bos SystemSafeBOS {

  // NOTE: This alphabet is exactly 64 bytes long.
  // Indices 0..63 map to:
  //   0..25  -> a..z
  //   26..51 -> A..Z
  //   52..61 -> 0..9
  //   62     -> space
  //   63     -> newline (ASCII 10)
  const String ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \n";
  const UInt64 BASE = 64u;
  const UInt64 UINT64_MAX = 18446744073709551615u;

  // Output sink used by the permutation generator.
  interface OutputSink {
    // Write exactly `count` bytes from `data` (ASCII/byte-accurate).
    boolean writeBytes(ByteArray data, UInt64 count);

    // Write a single byte/char.
    boolean writeChar(Byte c);

    // Close and release resources.
    void close();
  }

  // File-backed sink (mirrors the assembly's fwrite/fputc behavior).
  class FileSink implements OutputSink {
    private FileHandle fh;

    static FileSink open(String path) {
      FileHandle h = File.open(path, "w");    // text-mode write, like fopen(path,"w")
      if (h == null) return null;

      FileSink s = new FileSink();
      s.fh = h;
      return s;
    }

    boolean writeBytes(ByteArray data, UInt64 count) {
      // Return true iff we wrote exactly `count` bytes.
      UInt64 written = File.write(this.fh, data, 0u, count); // like fwrite(data,1,count,fh)
      return (written == count);
    }

    boolean writeChar(Byte c) {
      // Return true iff fputc succeeds.
      return File.putc(this.fh, c);
    }

    void close() {
      if (this.fh != null) {
        File.close(this.fh);
        this.fh = null;
      }
    }
  }

  // Equivalent of safe_uint64_power(base, exp, &out).
  // Returns false on overflow, true otherwise.
  static boolean safe_uint64_power(UInt64 base, UInt64 exp, out UInt64 outValue) {
    outValue = 1u;

    UInt64 i = 0u;
    while (i < exp) {
      // overflow check for outValue * base in UInt64
      if (base != 0u && outValue > (UINT64_MAX / base)) {
        return false;
      }
      outValue = outValue * base;
      i = i + 1u;
    }
    return true;
  }

  // Equivalent of generate_permutations(len, sink).
  static boolean generate_permutations(UInt64 len, OutputSink sink) {
    UInt64 limit;
    if (!safe_uint64_power(BASE, len, limit)) {
      return false;
    }

    // Empty-len case matches the assembly: write "" then '\n' once.
    // (limit == 1, loop runs once, buffer length 0, then newline)
    UInt64 i = 0u;
    while (i < limit) {
      UInt64 tmp = i;

      ByteArray buf = ByteArray.new(len);  // fixed-length byte buffer (ASCII bytes)

      // fill from right to left
      Int64 pos = (Int64)len - 1;
      while (pos >= 0) {
        UInt64 idx = (tmp & 63u);   // 6-bit digit
        Byte ch = (Byte)ALPHABET.charCodeAt((Int64)idx); // ASCII byte from ALPHABET[idx]
        buf[(UInt64)pos] = ch;

        tmp = (tmp >> 6);
        pos = pos - 1;
      }

      if (!sink.writeBytes(buf, len)) return false;
      if (!sink.writeChar((Byte)10))  return false; // newline after each record

      i = i + 1u;
    }
    return true;
  }
}

/* =========================
   DASL/AUS (Application Usage)
   ========================= */

aus SystemSafeAUS {

  // Minimal non-interactive "main task" wrapper.
  // Mirrors the assembly's main() behavior (len=4, out="system_safe.txt").
  task Main {
    action run() {

      UInt64 len = 4u;
      String outPath = "system_safe.txt";

      SystemSafeBOS.FileSink sink = SystemSafeBOS.FileSink.open(outPath);
      if (sink == null) {
        Console.perror("Error opening file");
        OS.exit(1);
      }

      boolean ok = SystemSafeBOS.generate_permutations(len, sink);
      sink.close();

      if (!ok) OS.exit(1);
      OS.exit(0);
    }
  }
}

```

<a id="file-11"></a>
### [11] `Ada.txt`

- **Bytes:** `5399`
- **Type:** `text`

```text
-- Ada.txt
-- Converted from the x86-64 assembly in assembly.txt into equivalent Ada (GNAT) code.
--
-- Behavior matches the assembly:
--   * ALPHABET is 64 bytes: a-z, A-Z, 0-9, space, LF.
--   * safe_uint64_power(64, N) detects overflow in 64-bit unsigned arithmetic.
--   * generate_permutations(N, sink) enumerates i = 0 .. 64^N-1 and forms an N-byte token
--     by taking base-64 digits (low 6 bits) from right to left, then writes the token and
--     appends '\n' (LF = 10).
--   * main uses N = 4 and output file "system_safe.txt".
--
-- Build (GNAT):
--   gnatmake -O2 main.adb
--
-- Run:
--   ./main
--
-- Output:
--   system_safe.txt
--
-- NOTE: Because ALPHABET itself contains LF as its 64th character AND we also append LF after
-- each token, some tokens contain embedded newlines. This is intentional and matches the
-- assembly output.

with Ada.Streams;
with Ada.Streams.Stream_IO;
with Ada.Text_IO;
with Ada.Characters.Latin_1;
with Interfaces;

procedure Main is
   use Ada.Streams;
   use Ada.Streams.Stream_IO;
   use Interfaces;

   -- 64-byte alphabet, exactly as in the assembly.
   Alphabet : constant String :=
     "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 "
       & Ada.Characters.Latin_1.LF;

   Max_N : constant Natural := 50;

   -- "OutputSink" equivalent (assembly stores: ctx pointer + function pointers).
   -- Here we implement only a file-backed sink like the assembly.
   type File_Sink is record
      F    : Ada.Streams.Stream_IO.File_Type;
      Open : Boolean := False;
   end record;

   function File_Sink_Init (S : in out File_Sink; Path : String) return Boolean is
   begin
      Create (File => S.F, Mode => Out_File, Name => Path);
      S.Open := True;
      return True;
   exception
      when others =>
         S.Open := False;
         return False;
   end File_Sink_Init;

   function File_Sink_Write (S : in out File_Sink;
                             Data : Stream_Element_Array) return Boolean is
   begin
      if not S.Open then
         return False;
      end if;
      Write (File => S.F, Item => Data);
      return True;
   exception
      when others =>
         return False;
   end File_Sink_Write;

   function File_Sink_Write_Char (S : in out File_Sink;
                                  C : Stream_Element) return Boolean is
      One : Stream_Element_Array (1 .. 1);
   begin
      One (1) := C;
      return File_Sink_Write (S, One);
   end File_Sink_Write_Char;

   procedure File_Sink_Close (S : in out File_Sink) is
   begin
      if S.Open then
         Close (S.F);
         S.Open := False;
      end if;
   exception
      when others =>
         S.Open := False;
   end File_Sink_Close;

   -- Overflow-checked power in Unsigned_64 (matches safe_uint64_power in assembly).
   function Safe_U64_Power (Base, Exp : Unsigned_64;
                            Out_Value : out Unsigned_64) return Boolean is
      Result : Unsigned_64 := 1;
      I      : Unsigned_64 := 0;
   begin
      while I < Exp loop
         -- Detect overflow: Result * Base must fit in Unsigned_64.
         if Base /= 0 and then Result > Unsigned_64'Last / Base then
            return False;
         end if;

         Result := Result * Base;
         I := I + 1;
      end loop;

      Out_Value := Result;
      return True;
   end Safe_U64_Power;

   function Generate_Permutations (N : Unsigned_64; S : in out File_Sink) return Boolean is
      Limit : Unsigned_64 := 0;
      Buf   : Stream_Element_Array (1 .. Max_N);
      N_Int : Natural;
      I     : Unsigned_64;
      V     : Unsigned_64;
      Idx   : Unsigned_64;

      LF_Byte : constant Stream_Element :=
        Stream_Element (Character'Pos (Ada.Characters.Latin_1.LF));
   begin
      if not S.Open then
         return False;
      end if;

      if N > Unsigned_64 (Max_N) then
         return False;
      end if;

      -- Compute Limit = 64^N with overflow detection.
      if not Safe_U64_Power (Base => 64, Exp => N, Out_Value => Limit) then
         return False;
      end if;

      N_Int := Natural (N); -- safe because N <= Max_N.

      -- For i in 0 .. Limit-1
      I := 0;
      while I < Limit loop
         V := I;

         -- Fill buffer from right to left.
         if N_Int > 0 then
            for Pos in reverse 1 .. N_Int loop
               Idx := V and 63;
               -- Alphabet is 1-based string; Idx is 0..63.
               Buf (Pos) :=
                 Stream_Element (Character'Pos (Alphabet (Natural (Idx) + 1)));
               V := Shift_Right (V, 6);
            end loop;

            if not File_Sink_Write (S, Buf (1 .. N_Int)) then
               return False;
            end if;
         end if;

         if not File_Sink_Write_Char (S, LF_Byte) then
            return False;
         end if;

         I := I + 1;
      end loop;

      return True;
   end Generate_Permutations;

   Sink : File_Sink;
   Ok   : Boolean;
begin
   -- main(): fixed N=4, file "system_safe.txt"
   if not File_Sink_Init (Sink, "system_safe.txt") then
      Ada.Text_IO.Put_Line ("Error opening file");
      return;
   end if;

   Ok := Generate_Permutations (N => 4, S => Sink);
   File_Sink_Close (Sink);

   if not Ok then
      -- Assembly returns exit code 1 on failure.
      -- GNAT: raise an exception to signal failure (or call OS_Exit).
      raise Program_Error with "Generation failed";
   end if;
end Main;

```

<a id="file-12"></a>
### [12] `assembly.txt`

- **Bytes:** `7299`
- **Type:** `text`

```text
ALPHABET:
        .ascii  "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ01234567"
        .ascii  "89 \n"
safe_uint64_power(unsigned long, unsigned long, unsigned long*):
        push    rbp
        mov     rbp, rsp
        mov     QWORD PTR [rbp-24], rdi
        mov     QWORD PTR [rbp-32], rsi
        mov     QWORD PTR [rbp-40], rdx
        mov     rax, QWORD PTR [rbp-40]
        mov     QWORD PTR [rax], 1
        mov     QWORD PTR [rbp-8], 0
        jmp     .L2
.L7:
        mov     rax, QWORD PTR [rbp-40]
        mov     rdx, QWORD PTR [rax]
        mov     ecx, 0
        mov     rax, rdx
        mul     QWORD PTR [rbp-24]
        jno     .L3
        mov     ecx, 1
.L3:
        mov     rax, rcx
        test    rax, rax
        je      .L5
        mov     eax, 0
        jmp     .L6
.L5:
        mov     rax, QWORD PTR [rbp-40]
        mov     rax, QWORD PTR [rax]
        imul    rax, QWORD PTR [rbp-24]
        mov     rdx, rax
        mov     rax, QWORD PTR [rbp-40]
        mov     QWORD PTR [rax], rdx
        add     QWORD PTR [rbp-8], 1
.L2:
        mov     rax, QWORD PTR [rbp-8]
        cmp     rax, QWORD PTR [rbp-32]
        jb      .L7
        mov     eax, 1
.L6:
        pop     rbp
        ret
generate_permutations(unsigned long, OutputSink*):
        push    rbp
        mov     rbp, rsp
        sub     rsp, 80
        mov     QWORD PTR [rbp-72], rdi
        mov     QWORD PTR [rbp-80], rsi
        lea     rdx, [rbp-40]
        mov     rax, QWORD PTR [rbp-72]
        mov     rsi, rax
        mov     edi, 64
        call    safe_uint64_power(unsigned long, unsigned long, unsigned long*)
        xor     eax, 1
        test    al, al
        je      .L9
        mov     eax, 0
        jmp     .L17
.L9:
        mov     QWORD PTR [rbp-8], 0
        jmp     .L11
.L16:
        mov     rax, QWORD PTR [rbp-8]
        mov     QWORD PTR [rbp-16], rax
        mov     rax, QWORD PTR [rbp-72]
        sub     rax, 1
        mov     QWORD PTR [rbp-24], rax
        jmp     .L12
.L13:
        mov     rax, QWORD PTR [rbp-16]
        and     eax, 63
        mov     QWORD PTR [rbp-32], rax
        mov     rax, QWORD PTR [rbp-32]
        add     rax, OFFSET FLAT:ALPHABET
        movzx   eax, BYTE PTR [rax]
        lea     rcx, [rbp-50]
        mov     rdx, QWORD PTR [rbp-24]
        add     rdx, rcx
        mov     BYTE PTR [rdx], al
        shr     QWORD PTR [rbp-16], 6
        sub     QWORD PTR [rbp-24], 1
.L12:
        cmp     QWORD PTR [rbp-24], 0
        jns     .L13
        mov     rax, QWORD PTR [rbp-80]
        mov     r8, QWORD PTR [rax+8]
        mov     rax, QWORD PTR [rbp-80]
        mov     rax, QWORD PTR [rax]
        mov     rdx, QWORD PTR [rbp-72]
        lea     rcx, [rbp-50]
        mov     rsi, rcx
        mov     rdi, rax
        call    r8
        xor     eax, 1
        test    al, al
        je      .L14
        mov     eax, 0
        jmp     .L17
.L14:
        mov     rax, QWORD PTR [rbp-80]
        mov     rdx, QWORD PTR [rax+16]
        mov     rax, QWORD PTR [rbp-80]
        mov     rax, QWORD PTR [rax]
        mov     esi, 10
        mov     rdi, rax
        call    rdx
        xor     eax, 1
        test    al, al
        je      .L15
        mov     eax, 0
        jmp     .L17
.L15:
        add     QWORD PTR [rbp-8], 1
.L11:
        mov     rax, QWORD PTR [rbp-40]
        cmp     QWORD PTR [rbp-8], rax
        jb      .L16
        mov     eax, 1
.L17:
        leave
        ret
file_sink_write(void*, char const*, unsigned long):
        push    rbp
        mov     rbp, rsp
        sub     rsp, 48
        mov     QWORD PTR [rbp-24], rdi
        mov     QWORD PTR [rbp-32], rsi
        mov     QWORD PTR [rbp-40], rdx
        mov     rax, QWORD PTR [rbp-24]
        mov     QWORD PTR [rbp-8], rax
        mov     rcx, QWORD PTR [rbp-8]
        mov     rdx, QWORD PTR [rbp-40]
        mov     rax, QWORD PTR [rbp-32]
        mov     esi, 1
        mov     rdi, rax
        call    fwrite
        cmp     QWORD PTR [rbp-40], rax
        sete    al
        leave
        ret
file_sink_write_char(void*, char):
        push    rbp
        mov     rbp, rsp
        sub     rsp, 32
        mov     QWORD PTR [rbp-24], rdi
        mov     eax, esi
        mov     BYTE PTR [rbp-28], al
        mov     rax, QWORD PTR [rbp-24]
        mov     QWORD PTR [rbp-8], rax
        movsx   eax, BYTE PTR [rbp-28]
        mov     rdx, QWORD PTR [rbp-8]
        mov     rsi, rdx
        mov     edi, eax
        call    fputc
        cmp     eax, -1
        setne   al
        leave
        ret
.LC0:
        .string "w"
file_sink_init(OutputSink*, char const*):
        push    rbp
        mov     rbp, rsp
        sub     rsp, 32
        mov     QWORD PTR [rbp-24], rdi
        mov     QWORD PTR [rbp-32], rsi
        mov     rax, QWORD PTR [rbp-32]
        mov     esi, OFFSET FLAT:.LC0
        mov     rdi, rax
        call    fopen
        mov     QWORD PTR [rbp-8], rax
        cmp     QWORD PTR [rbp-8], 0
        jne     .L23
        mov     eax, 0
        jmp     .L24
.L23:
        mov     rax, QWORD PTR [rbp-24]
        mov     rdx, QWORD PTR [rbp-8]
        mov     QWORD PTR [rax], rdx
        mov     rax, QWORD PTR [rbp-24]
        mov     QWORD PTR [rax+8], OFFSET FLAT:file_sink_write(void*, char const*, unsigned long)
        mov     rax, QWORD PTR [rbp-24]
        mov     QWORD PTR [rax+16], OFFSET FLAT:file_sink_write_char(void*, char)
        mov     eax, 1
.L24:
        leave
        ret
file_sink_close(OutputSink*):
        push    rbp
        mov     rbp, rsp
        sub     rsp, 16
        mov     QWORD PTR [rbp-8], rdi
        cmp     QWORD PTR [rbp-8], 0
        je      .L27
        mov     rax, QWORD PTR [rbp-8]
        mov     rax, QWORD PTR [rax]
        test    rax, rax
        je      .L27
        mov     rax, QWORD PTR [rbp-8]
        mov     rax, QWORD PTR [rax]
        mov     rdi, rax
        call    fclose
        mov     rax, QWORD PTR [rbp-8]
        mov     QWORD PTR [rax], 0
.L27:
        nop
        leave
        ret
.LC1:
        .string "system_safe.txt"
.LC2:
        .string "Error opening file"
main:
        push    rbp
        mov     rbp, rsp
        sub     rsp, 48
        mov     QWORD PTR [rbp-8], 4
        lea     rax, [rbp-48]
        mov     esi, OFFSET FLAT:.LC1
        mov     rdi, rax
        call    file_sink_init(OutputSink*, char const*)
        xor     eax, 1
        test    al, al
        je      .L29
        mov     edi, OFFSET FLAT:.LC2
        call    perror
        mov     eax, 1
        jmp     .L32
.L29:
        lea     rax, [rbp-48]
        mov     rsi, rax
        mov     edi, 4
        call    generate_permutations(unsigned long, OutputSink*)
        mov     BYTE PTR [rbp-9], al
        lea     rax, [rbp-48]
        mov     rdi, rax
        call    file_sink_close(OutputSink*)
        movzx   eax, BYTE PTR [rbp-9]
        xor     eax, 1
        test    al, al
        je      .L31
        mov     eax, 1
        jmp     .L32
.L31:
        mov     eax, 0
.L32:
        leave
        ret
```

<a id="file-13"></a>
### [13] `bundle_documentation.py`

- **Bytes:** `9220`
- **Type:** `text`

````python
#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as _dt
import os
import re
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple, Union

# ---- CONFIG ----
TEXT_EXTENSIONS = {
    ".css", ".cmd", ".js", ".php", ".hpp", ".cpp", ".md", ".py", ".txt", ".ps1", ".json", ".html", ".h"
}
IMAGE_EXTENSIONS = {".png"}

SPECIAL_FILENAMES = {".env", ".gitignore"}  # extensionless-but-important

IGNORE_DIRS = {
    ".git", ".svn", ".hg",
    "node_modules", "vendor",
    "venv", ".venv", "__pycache__",
    "dist", "build",
    ".idea", ".vscode",
    "doc",  # prevent bundling the bundle output folder itself
}

MAX_TEXT_FILE_BYTES = 5_000_000  # 5MB cap for *text* files


# ---- HELPERS ----
def is_probably_binary(path: Path, sample_size: int = 4096) -> bool:
    try:
        with path.open("rb") as f:
            chunk = f.read(sample_size)
        return b"\x00" in chunk
    except Exception:
        return True


def is_text_included(path: Path) -> bool:
    if path.name in SPECIAL_FILENAMES:
        return True
    return path.suffix.lower() in TEXT_EXTENSIONS


def is_png(path: Path) -> bool:
    return path.suffix.lower() == ".png"


def is_included_any(path: Path) -> bool:
    return is_text_included(path) or (path.suffix.lower() in IMAGE_EXTENSIONS)


def iter_included_paths(root: Path) -> Iterable[Path]:
    for dirpath, dirnames, filenames in os.walk(root):
        # prune ignored dirs
        dirnames[:] = [d for d in dirnames if d not in IGNORE_DIRS]

        for name in filenames:
            p = Path(dirpath) / name
            if p.is_file() and is_included_any(p):
                yield p


def read_text(path: Path) -> Tuple[str, str]:
    """
    Returns (content, note). note is "" when OK.
    """
    try:
        size = path.stat().st_size
        if size > MAX_TEXT_FILE_BYTES:
            return "", f"Skipped (too large): {size} bytes > {MAX_TEXT_FILE_BYTES}"
        if is_probably_binary(path):
            return "", "Skipped (binary detected)"
        return path.read_text(encoding="utf-8", errors="replace"), ""
    except Exception as e:
        return "", f"Error reading: {e}"


def detect_code_lang(path: Path) -> str:
    ext = path.suffix.lower()
    return {
        ".py": "python",
        ".js": "javascript",
        ".ts": "typescript",
        ".json": "json",
        ".html": "html",
        ".css": "css",
        ".ps1": "powershell",
        ".cmd": "bat",
        ".cpp": "cpp",
        ".hpp": "cpp",
        ".php": "php",
        ".md": "markdown",
        ".txt": "text",
        "": "text",
    }.get(ext, "text")


def fenced_block(content: str, lang: str) -> str:
    """
    Create a fenced code block that won't break if the content contains ``` already.
    """
    # Find the longest run of backticks in the content
    runs = [len(m.group(0)) for m in re.finditer(r"`+", content)]
    fence_len = max(runs) + 1 if runs else 3
    fence = "`" * max(3, fence_len)
    return f"{fence}{lang}\n{content}\n{fence}\n"


def relpath_posix(from_dir: Path, to_path: Path) -> str:
    rel = os.path.relpath(to_path, start=from_dir)
    return Path(rel).as_posix()


def png_dimensions(path: Path) -> Optional[Tuple[int, int]]:
    """
    Parse PNG IHDR to get (width, height) without external dependencies.
    Returns None if unreadable/not PNG.
    """
    try:
        with path.open("rb") as f:
            header = f.read(24)
        if len(header) < 24:
            return None
        sig = header[:8]
        if sig != b"\x89PNG\r\n\x1a\n":
            return None
        chunk_type = header[12:16]
        if chunk_type != b"IHDR":
            return None
        w = int.from_bytes(header[16:20], "big")
        h = int.from_bytes(header[20:24], "big")
        return (w, h)
    except Exception:
        return None


# ---- TREE BUILD + RENDER ----
TreeNode = Dict[str, Union["TreeNode", None]]  # None means leaf file


def build_tree(relpaths: List[Path]) -> TreeNode:
    root: TreeNode = {}
    for rp in relpaths:
        cur = root
        parts = rp.parts
        for i, part in enumerate(parts):
            is_last = (i == len(parts) - 1)
            if is_last:
                cur.setdefault(part, None)
            else:
                nxt = cur.get(part)
                if nxt is None:
                    cur[part] = {}
                cur = cur[part]  # type: ignore[assignment]
    return root


def render_tree(tree: TreeNode, prefix: str = "") -> List[str]:
    """
    ASCII tree with deterministic ordering:
    directories first, then files, each group alphabetically.
    """
    lines: List[str] = []
    items = list(tree.items())

    def is_dir(item):
        _, v = item
        return isinstance(v, dict)

    dirs = sorted([it for it in items if is_dir(it)], key=lambda x: x[0].lower())
    files = sorted([it for it in items if not is_dir(it)], key=lambda x: x[0].lower())
    ordered = dirs + files

    for idx, (name, node) in enumerate(ordered):
        last = (idx == len(ordered) - 1)
        branch = "└── " if last else "├── "
        lines.append(prefix + branch + name)

        if isinstance(node, dict):
            extension = "    " if last else "│   "
            lines.extend(render_tree(node, prefix + extension))

    return lines


# ---- MAIN OUTPUT ----
def create_doc_md(root: Path, outpath: Path) -> Path:
    files = sorted(iter_included_paths(root), key=lambda p: p.relative_to(root).as_posix().lower())
    relpaths = [p.relative_to(root) for p in files]

    tree = build_tree(relpaths)
    tree_lines = [root.name or root.as_posix()] + render_tree(tree)

    outpath.parent.mkdir(parents=True, exist_ok=True)

    now = _dt.datetime.now().isoformat(timespec="seconds")

    with outpath.open("w", encoding="utf-8") as out:
        # Header
        out.write("# Documentation Bundle\n\n")
        out.write(f"- **Root:** `{root}`\n")
        out.write(f"- **Generated:** `{now}`\n")
        out.write(f"- **Included files:** `{len(files)}`\n")
        out.write(f"- **Max text file bytes:** `{MAX_TEXT_FILE_BYTES}`\n")
        out.write(f"- **Ignored dirs:** `{', '.join(sorted(IGNORE_DIRS))}`\n\n")

        # Tree view
        out.write("## Filesystem Tree (included paths)\n\n")
        out.write(fenced_block("\n".join(tree_lines), "text"))
        out.write("\n")

        # TOC
        out.write("## Table of Contents\n\n")
        for i, rp in enumerate(relpaths, start=1):
            out.write(f"{i}. [`{rp.as_posix()}`](#file-{i})\n")
        out.write("\n")

        # File contents
        out.write("## File Contents\n\n")
        for i, path in enumerate(files, start=1):
            rp = path.relative_to(root).as_posix()
            out.write(f'<a id="file-{i}"></a>\n')
            out.write(f"### [{i}] `{rp}`\n\n")

            size = path.stat().st_size
            out.write(f"- **Bytes:** `{size}`\n")

            if is_png(path):
                out.write("- **Type:** `png`\n")
                dims = png_dimensions(path)
                if dims:
                    out.write(f"- **Dimensions:** `{dims[0]}×{dims[1]}`\n")
                elif size == 0:
                    out.write("- **Dimensions:** `unknown (empty file)`\n")
                else:
                    out.write("- **Dimensions:** `unknown`\n")

                # Embed image (path relative to the markdown file location)
                md_rel = relpath_posix(outpath.parent, path)
                out.write(f"- **Path (from doc):** `{md_rel}`\n\n")
                out.write(f"![{rp}]({md_rel})\n\n")
                continue

            # Text file
            out.write("- **Type:** `text`\n")
            content, note = read_text(path)
            if note:
                out.write(f"- **NOTE:** {note}\n")
            out.write("\n")

            if content:
                lang = detect_code_lang(path)
                out.write(fenced_block(content, lang))
                out.write("\n")
            else:
                out.write("_No content (skipped or empty)._ \n\n")

    return outpath


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Bundle repository documentation into doc/doc.md (including .png images)."
    )
    parser.add_argument(
        "--root",
        type=Path,
        default=Path(__file__).resolve().parent,
        help="Root folder to scan (default: script directory).",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=None,
        help="Output markdown path (default: <root>/doc/doc.md).",
    )
    args = parser.parse_args()

    root = args.root.resolve()
    out = (args.out.resolve() if args.out else (root / "doc" / "doc.md"))

    outpath = create_doc_md(root, out)
    print(f"Documentation updated: Created '{outpath}'")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

````

<a id="file-14"></a>
### [14] `C.txt`

- **Bytes:** `4671`
- **Type:** `text`

```text
/**
 * @file main.c
 * @brief Permutation Generator in C, architected to safety-critical standards.
 *
 * @author Dominic Alexander Cooper (Original Algorithm)
 * @author Gemini (Architectural Refactoring)
 *
 * @details
 * This program generates all possible character combinations for a given length,
 * based on a predefined character set. It is a complete rewrite of the original
 * concept to align with principles of safety-critical software design.
 */
#include <stdio.h>
#include <stdint.h> // For fixed-width integer types like uint64_t
#include <stdbool.h> // For bool type
#include <limits.h> // For UINT64_MAX
//==============================================================================
// 1. CONFIGURATION AND DATA DEFINITIONS
//==============================================================================
#define MAX_PERMUTATION_LENGTH 10
static const char ALPHABET[] = {
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
    'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
    'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ' ', '\n'
};
static const uint64_t ALPHABET_SIZE = sizeof(ALPHABET) / sizeof(ALPHABET[0]);
//==============================================================================
// 2. ABSTRACT INTERFACE FOR OUTPUT (OutputSink)
//==============================================================================
typedef struct {
    void* context;
    bool (*write)(void* context, const char* buffer, uint64_t size);
    bool (*write_char)(void* context, char c);
} OutputSink;
//==============================================================================
// 3. CORE LOGIC (Generator)
//==============================================================================
static bool safe_uint64_power(uint64_t base, uint64_t exp, uint64_t* result) {
    *result = 1;
    for (uint64_t i = 0; i < exp; ++i) {
        if (*result > UINT64_MAX / base) {
            return false;
        }
        *result *= base;
    }
    return true;
}
static bool generate_permutations(uint64_t length, OutputSink* sink) {
    uint64_t num_combinations;
    if (!safe_uint64_power(ALPHABET_SIZE, length, &num_combinations)) {
        return false;
    }
    char current_perm[MAX_PERMUTATION_LENGTH];
    for (uint64_t i = 0; i < num_combinations; ++i) {
        uint64_t temp_row = i;
        for (int64_t j = length - 1; j >= 0; --j) {
            uint64_t char_index = temp_row % ALPHABET_SIZE;
            current_perm[j] = ALPHABET[char_index];
            temp_row /= ALPHABET_SIZE;
        }
        if (!sink->write(sink->context, current_perm, length)) {
            return false;
        }
        if (!sink->write_char(sink->context, '\n')) {
            return false;
        }
    }
    return true;
}
//==============================================================================
// 4. CONCRETE IMPLEMENTATION OF OUTPUTSINK (FileSink)
//==============================================================================
static bool file_sink_write(void* context, const char* buffer, uint64_t size) {
    FILE* p = (FILE*)context;
    return fwrite(buffer, sizeof(char), size, p) == size;
}
static bool file_sink_write_char(void* context, char c) {
    FILE* p = (FILE*)context;
    return fputc(c, p) != EOF;
}
static bool file_sink_init(OutputSink* sink, const char* filename) {
    FILE* p = fopen(filename, "w");
    if (p == NULL) {
        return false;
    }
    *sink = (OutputSink){
        .context = p,
        .write = file_sink_write,
        .write_char = file_sink_write_char
    };
    return true;
}
static void file_sink_close(OutputSink* sink) {
    if (sink && sink->context) {
        fclose((FILE*)sink->context);
        sink->context = NULL;
    }
}
//==============================================================================
// 5. SYSTEM ASSEMBLER (main)
//==============================================================================
int main(void) {
    const uint64_t permutation_length = 4;
    if (permutation_length == 0 || permutation_length > MAX_PERMUTATION_LENGTH) {
        return 1;
    }
    OutputSink file_sink;
    if (!file_sink_init(&file_sink, "system_safe.txt")) {
        perror("Error opening file");
        return 1;
    }
    bool success = generate_permutations(permutation_length, &file_sink);
    file_sink_close(&file_sink);
    if (!success) {
        return 1;
    }
    return 0;
}

```

<a id="file-15"></a>
### [15] `cpp.txt`

- **Bytes:** `3677`
- **Type:** `text`

```text
// cpp.txt
// High-level C++ translation of the attached x86-64 assembly.
//
// What it does (same behavior as assembly):
// - Defines a 64-character alphabet (a-z, A-Z, 0-9, space, newline).
// - Computes 64^N safely in uint64_t (detecting overflow).
// - Iterates i in [0, 64^N) and maps i to an N-character "base-64" word using the alphabet.
// - Writes each word, then writes '\n', to "system_safe.txt".
//
// NOTE: For N=4 this writes 16,777,216 lines (~80+ MiB). Increase N with care.

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>
#include <string>

static constexpr char ALPHABET[] =
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ01234567"
    "89 \n"; // total 64 chars

struct OutputSink {
    void* ctx = nullptr; // e.g., FILE*
    bool (*write)(void*, const char*, unsigned long) = nullptr;
    bool (*write_char)(void*, char) = nullptr;
};

// Returns true on success, false if uint64 overflow would occur.
// Computes: *out = base^exp, using repeated multiplication (as in the assembly).
static bool safe_uint64_power(std::uint64_t base, std::uint64_t exp, std::uint64_t* out) {
    if (!out) return false;
    std::uint64_t value = 1;

    for (std::uint64_t i = 0; i < exp; ++i) {
        if (base != 0 && value > (std::numeric_limits<std::uint64_t>::max() / base)) {
            return false; // overflow
        }
        value *= base;
    }

    *out = value;
    return true;
}

static bool generate_permutations(std::uint64_t n, OutputSink* sink) {
    if (!sink || !sink->write || !sink->write_char) return false;

    std::uint64_t total = 0;
    if (!safe_uint64_power(64ULL, n, &total)) {
        return false;
    }

    std::string buf;
    buf.resize(static_cast<std::size_t>(n));

    for (std::uint64_t i = 0; i < total; ++i) {
        std::uint64_t x = i;

        // Fill from the end down to 0 (same as the assembly).
        // Uses 6-bit chunks (x & 63), then shifts x >>= 6.
        for (std::int64_t idx = static_cast<std::int64_t>(n) - 1; idx >= 0; --idx) {
            std::uint64_t a = (x & 63ULL);
            buf[static_cast<std::size_t>(idx)] = ALPHABET[a];
            x >>= 6;
        }

        if (!sink->write(sink->ctx, buf.data(), static_cast<unsigned long>(n))) {
            return false;
        }
        if (!sink->write_char(sink->ctx, '\n')) {
            return false;
        }
    }

    return true;
}

// --- File sink implementation (matches the assembly's semantics) ---

static bool file_sink_write(void* ctx, const char* data, unsigned long len) {
    std::FILE* f = static_cast<std::FILE*>(ctx);
    if (!f) return false;
    return std::fwrite(data, 1, len, f) == len;
}

static bool file_sink_write_char(void* ctx, char c) {
    std::FILE* f = static_cast<std::FILE*>(ctx);
    if (!f) return false;
    return std::fputc(static_cast<unsigned char>(c), f) != EOF;
}

static bool file_sink_init(OutputSink* sink, const char* path) {
    if (!sink || !path) return false;

    std::FILE* f = std::fopen(path, "w");
    if (!f) return false;

    sink->ctx = f;
    sink->write = &file_sink_write;
    sink->write_char = &file_sink_write_char;
    return true;
}

static void file_sink_close(OutputSink* sink) {
    if (!sink) return;
    if (sink->ctx) {
        std::fclose(static_cast<std::FILE*>(sink->ctx));
        sink->ctx = nullptr;
    }
}

int main() {
    const std::uint64_t N = 4; // same as assembly main

    OutputSink sink;
    if (!file_sink_init(&sink, "system_safe.txt")) {
        std::perror("Error opening file");
        return 1;
    }

    const bool ok = generate_permutations(N, &sink);

    file_sink_close(&sink);
    return ok ? 0 : 1;
}

```

<a id="file-16"></a>
### [16] `D.txt`

- **Bytes:** `4057`
- **Type:** `text`

```text
// D.txt
// Converted from assembly.txt (x86-64) into equivalent D source.
//
// Behavior matches the assembly:
//
// - ALPHABET is 64 bytes: a-z, A-Z, 0-9, space, newline.
// - safe_uint64_power(64, N) detects overflow in u64.
// - generate_permutations(N, &sink) emits 64^N tokens, each N bytes, derived from i in base-64
//   (low 6 bits per digit, filled from right to left), and then appends '\n'.
// - main uses N = 4 and output path "system_safe.txt".
//
// Build (Linux/macOS):
//   dmd -O -release main.d
// or
//   ldc2 -O3 -release main.d
//
// Run:
//   ./main
//
// Output:
//   system_safe.txt
//
// NOTE: Because ALPHABET includes '\n' as its last character, some generated tokens contain embedded
// newlines in addition to the trailing '\n'. This is intentional and matches the assembly output.

module main;

import core.stdc.stdio : FILE, fopen, fwrite, fputc, fclose, perror, EOF;
import core.stdc.stdlib : exit;
import core.stdc.string : strlen;
import core.stdc.stdint : uint64_t, UINT64_MAX;
import core.stdc.stddef : size_t;

alias u64 = uint64_t;

enum ubyte[64] ALPHABET = cast(ubyte[64])"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \n";

alias WriteFn = bool function(void* ctx, const(char)* bytes, size_t len) nothrow @nogc;
alias WriteCharFn = bool function(void* ctx, char c) nothrow @nogc;

struct OutputSink {
    void* ctx;
    WriteFn write;
    WriteCharFn writeChar;
}

nothrow @nogc
bool safe_uint64_power(u64 base, u64 exp, u64* out) {
    if (out is null) return false;

    *out = 1;
    for (u64 i = 0; i < exp; i++) {
        // Detect overflow in (*out) * base.
        if (base != 0 && *out > (UINT64_MAX / base)) {
            return false;
        }
        *out *= base;
    }
    return true;
}

nothrow @nogc
bool file_sink_write(void* ctx, const(char)* bytes, size_t len) {
    if (ctx is null || bytes is null) return false;
    auto fp = cast(FILE*)ctx;
    const size_t wrote = fwrite(cast(const(void)*)bytes, 1, len, fp);
    return wrote == len;
}

nothrow @nogc
bool file_sink_write_char(void* ctx, char c) {
    if (ctx is null) return false;
    auto fp = cast(FILE*)ctx;
    return fputc(cast(int)c, fp) != EOF;
}

nothrow @nogc
bool file_sink_init(OutputSink* sink, const(char)* path) {
    if (sink is null || path is null) return false;

    auto fp = fopen(path, "w");
    if (fp is null) return false;

    sink.ctx = cast(void*)fp;
    sink.write = &file_sink_write;
    sink.writeChar = &file_sink_write_char;
    return true;
}

nothrow @nogc
void file_sink_close(OutputSink* sink) {
    if (sink is null) return;
    if (sink.ctx !is null) {
        auto fp = cast(FILE*)sink.ctx;
        fclose(fp);
        sink.ctx = null;
    }
}

bool generate_permutations(u64 n, OutputSink* sink) {
    if (sink is null || sink.write is null || sink.writeChar is null) return false;

    u64 limit = 0;
    if (!safe_uint64_power(64, n, &limit)) return false;

    // The assembly uses a stack buffer and writes exactly N bytes each iteration.
    // Here we allocate an N-byte array on the GC heap; for N=4 this is tiny.
    // (If you want @nogc end-to-end, use a fixed-size buffer as in the assembly.)
    auto buf = new ubyte[](cast(size_t)n);

    for (u64 i = 0; i < limit; i++) {
        u64 v = i;

        // Fill from right to left.
        for (long pos = cast(long)n - 1; pos >= 0; pos--) {
            const size_t idx = cast(size_t)(v & 63);
            buf[cast(size_t)pos] = ALPHABET[idx];
            v >>= 6;
        }

        if (!sink.write(sink.ctx, cast(const(char)*)buf.ptr, buf.length)) return false;
        if (!sink.writeChar(sink.ctx, '\n')) return false;
    }

    return true;
}

extern(C) int main() {
    enum u64 N = 4;
    enum string OUT_PATH = "system_safe.txt";
    enum string ERR_MSG = "Error opening file";

    OutputSink sink;
    if (!file_sink_init(&sink, OUT_PATH.ptr)) {
        perror(ERR_MSG.ptr);
        return 1;
    }

    const bool ok = generate_permutations(N, &sink);
    file_sink_close(&sink);

    return ok ? 0 : 1;
}

```

<a id="file-17"></a>
### [17] `Fortran.txt`

- **Bytes:** `4634`
- **Type:** `text`

```text
! Fortran.txt
! Converted from assembly.txt (x86-64) into equivalent Fortran (F2008+) source.
!
! Behavior matches the assembly:
! - ALPHABET is 64 bytes: a-z, A-Z, 0-9, space, newline.
! - safe_uint64_power(64, N) detects overflow (within signed int64 range).
! - generate_permutations(N, sink) emits 64^N tokens, each N bytes derived from i in base-64
!   (low 6 bits per digit, filled from right to left), then appends '\n'.
! - main uses N = 4 and output path "system_safe.txt".
!
! Build (gfortran):
!   gfortran -O2 -std=f2008 main.f90 -o system_safe
!
! Run:
!   ./system_safe
!
! Output:
!   system_safe.txt
!
! NOTE: Because ALPHABET includes '\n' as its last character, some generated tokens contain embedded
! newlines in addition to the trailing '\n'. This is intentional and matches the assembly output.

module system_safe_mod
  use, intrinsic :: iso_fortran_env, only: int64
  implicit none
  private
  public :: OutputSink, safe_uint64_power, generate_permutations

  character(len=64), parameter :: ALPHABET = &
       "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 " // achar(10)

  type :: OutputSink
     integer :: unit = -1
     logical :: is_open = .false.
   contains
     procedure :: init       => file_sink_init
     procedure :: write_bytes => file_sink_write
     procedure :: write_char  => file_sink_write_char
     procedure :: close      => file_sink_close
  end type OutputSink

contains

  logical function safe_uint64_power(base, exp, out) result(ok)
    integer(int64), intent(in)  :: base, exp
    integer(int64), intent(out) :: out
    integer(int64) :: i

    out = 1_int64
    ok = .true.

    do i = 1_int64, exp
       if (base /= 0_int64) then
          ! Overflow check (conservative for signed int64)
          if (out > huge(out) / base) then
             ok = .false.
             return
          end if
       end if
       out = out * base
    end do
  end function safe_uint64_power

  logical function file_sink_init(this, path) result(ok)
    class(OutputSink), intent(inout) :: this
    character(len=*), intent(in)     :: path
    integer :: ios

    ok = .false.
    this%is_open = .false.
    this%unit = -1

    open(newunit=this%unit, file=path, status="replace", &
         access="stream", form="unformatted", action="write", iostat=ios)

    if (ios == 0) then
       this%is_open = .true.
       ok = .true.
    end if
  end function file_sink_init

  logical function file_sink_write(this, bytes) result(ok)
    class(OutputSink), intent(inout) :: this
    character(len=*), intent(in)     :: bytes
    integer :: ios

    if (.not. this%is_open) then
       ok = .false.
       return
    end if

    write(this%unit, iostat=ios) bytes
    ok = (ios == 0)
  end function file_sink_write

  logical function file_sink_write_char(this, ch) result(ok)
    class(OutputSink), intent(inout) :: this
    character(len=1), intent(in)     :: ch
    integer :: ios

    if (.not. this%is_open) then
       ok = .false.
       return
    end if

    write(this%unit, iostat=ios) ch
    ok = (ios == 0)
  end function file_sink_write_char

  subroutine file_sink_close(this)
    class(OutputSink), intent(inout) :: this
    if (this%is_open) then
       close(this%unit)
       this%is_open = .false.
       this%unit = -1
    end if
  end subroutine file_sink_close

  logical function generate_permutations(n, sink) result(ok)
    integer(int64), intent(in)      :: n
    type(OutputSink), intent(inout) :: sink

    integer(int64) :: limit, i, v, idx
    integer :: pos, n_int, k
    character(len=50) :: buf

    ok = .false.

    if (.not. safe_uint64_power(64_int64, n, limit)) return
    if (n < 0_int64 .or. n > 50_int64) return
    if (.not. sink%is_open) return

    n_int = int(n)

    do i = 0_int64, limit - 1_int64
       v = i

       ! Fill from right to left
       do pos = n_int, 1, -1
          idx = iand(v, 63_int64)
          k = int(idx) + 1
          buf(pos:pos) = ALPHABET(k:k)
          v = ishft(v, -6)
       end do

       if (.not. sink%write_bytes(buf(1:n_int))) return
       if (.not. sink%write_char(achar(10))) return
    end do

    ok = .true.
  end function generate_permutations

end module system_safe_mod


program system_safe
  use, intrinsic :: iso_fortran_env, only: int64
  use system_safe_mod
  implicit none

  type(OutputSink) :: sink
  logical :: ok

  ok = sink%init("system_safe.txt")
  if (.not. ok) then
     write(*,*) "Error opening file"
     stop 1
  end if

  ok = generate_permutations(4_int64, sink)
  call sink%close()

  if (ok) then
     stop 0
  else
     stop 1
  end if
end program system_safe

```

<a id="file-18"></a>
### [18] `Nim.txt`

- **Bytes:** `2305`
- **Type:** `text`

```text
# Nim.txt
# Converted from the x86-64 assembly in assembly.txt into equivalent Nim code.
#
# Behavior matches the assembly:
#   * ALPHABET is 64 bytes: a-z, A-Z, 0-9, space, LF.
#   * safe_uint64_power(64, N) detects overflow in uint64.
#   * generate_permutations(N, file) enumerates i = 0 .. 64^N-1 and forms an N-byte token
#     by taking base-64 digits (low 6 bits) from right to left, then writes the token and
#     appends '\n' (LF = 10).
#   * main uses N = 4 and output file "system_safe.txt".
#
# Build:
#   nim c -d:release main.nim
#
# Run:
#   ./main
#
# Output:
#   system_safe.txt
#
# NOTE: Because ALPHABET itself contains LF as its 64th character AND we also append LF after
# each token, some tokens contain embedded newlines. This is intentional and matches the
# assembly output.

import std/os

const
  Alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \n" # 64 chars
  MaxN = 50

static:
  doAssert Alphabet.len == 64, "Alphabet must be exactly 64 characters"

proc safeUint64Power(base, exp: uint64; outVal: var uint64): bool =
  ## Returns false if overflow would occur.
  var result: uint64 = 1
  var i: uint64 = 0
  while i < exp:
    if base != 0'u64 and result > high(uint64) div base:
      return false
    result = result * base
    inc i
  outVal = result
  true

proc generatePermutations(n: uint64; f: var File): bool =
  var limit: uint64
  if not safeUint64Power(64'u64, n, limit):
    return false

  let nInt = int(n)
  if nInt < 0 or nInt > MaxN:
    return false

  var buf: array[MaxN, char]

  var i: uint64 = 0
  while i < limit:
    var v = i

    # Fill from right to left
    var pos = nInt - 1
    while pos >= 0:
      let idx = int(v and 63'u64) # 0..63
      buf[pos] = Alphabet[idx]
      v = v shr 6
      dec pos

    # Write exactly N bytes, then '\n'
    let wrote = f.writeBuffer(unsafeAddr buf[0], nInt)
    if wrote != nInt:
      return false
    f.write('\n')

    inc i

  true

when isMainModule:
  const N: uint64 = 4
  const OutPath = "system_safe.txt"

  var f: File
  if not open(f, OutPath, fmWrite):
    # Similar to perror("Error opening file") in assembly.
    stderr.writeLine("Error opening file: " & osLastErrorMsg())
    quit(1)

  let ok = generatePermutations(N, f)
  close(f)

  quit(if ok: 0 else: 1)

```

<a id="file-19"></a>
### [19] `Objective-C.txt`

- **Bytes:** `4005`
- **Type:** `text`

```text
// Objective-C.txt
// Converted from the attached x86-64 assembly listing (safe_uint64_power, generate_permutations,
// file-backed OutputSink, and main).  fileciteturn0file0
//
// Notes:
// - This program generates all base-64 "digits" strings of length N using a 64-character alphabet.
// - The number of outputs is 64^N. For N=4, that is 16,777,216 lines (~84 MB including newlines).
// - Overflow is detected when computing 64^N into a uint64_t.
//
// Build (macOS / Xcode toolchain):
//   clang -fobjc-arc -framework Foundation main.m -O2 -o system_safe
//
// Run:
//   ./system_safe            # defaults: N=4, output=system_safe.txt
//   ./system_safe 3 out.txt  # N=3, output=out.txt

#import <Foundation/Foundation.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

static const char ALPHABET[65] =
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \n"; // 64 chars + NUL

static BOOL safe_uint64_power(uint64_t base, uint64_t exp, uint64_t *out) {
    if (!out) return NO;
    uint64_t result = 1;

    for (uint64_t i = 0; i < exp; i++) {
        // Detect overflow: result * base must fit in uint64_t.
        if (base != 0 && result > UINT64_MAX / base) {
            return NO;
        }
        result *= base;
    }

    *out = result;
    return YES;
}

@protocol OutputSink <NSObject>
- (BOOL)writeBytes:(const char *)bytes length:(NSUInteger)length;
- (BOOL)writeChar:(char)c;
- (void)close;
@end

@interface FileSink : NSObject <OutputSink>
@property(nonatomic, assign) FILE *fp;
- (instancetype)initWithPath:(NSString *)path;
@end

@implementation FileSink

- (instancetype)initWithPath:(NSString *)path {
    self = [super init];
    if (!self) return nil;

    const char *cpath = [path fileSystemRepresentation];
    FILE *f = fopen(cpath, "w");
    if (!f) return nil;

    _fp = f;
    return self;
}

- (BOOL)writeBytes:(const char *)bytes length:(NSUInteger)length {
    if (!_fp || !bytes) return NO;
    size_t wrote = fwrite(bytes, 1, (size_t)length, _fp);
    return wrote == (size_t)length;
}

- (BOOL)writeChar:(char)c {
    if (!_fp) return NO;
    int rc = fputc((unsigned char)c, _fp);
    return rc != EOF;
}

- (void)close {
    if (_fp) {
        fclose(_fp);
        _fp = NULL;
    }
}

- (void)dealloc {
    [self close];
}

@end

static BOOL generate_permutations(uint64_t n, id<OutputSink> sink) {
    if (!sink) return NO;

    uint64_t limit = 0;
    if (!safe_uint64_power(64ULL, n, &limit)) {
        return NO;
    }

    // Allocate buffer for the N-character token (no terminator needed).
    char *buf = (char *)malloc((size_t)n);
    if (!buf) return NO;

    for (uint64_t i = 0; i < limit; i++) {
        uint64_t v = i;
        for (NSInteger pos = (NSInteger)n - 1; pos >= 0; pos--) {
            uint64_t idx = v & 63ULL;
            buf[pos] = ALPHABET[idx];
            v >>= 6;
        }

        if (![sink writeBytes:buf length:(NSUInteger)n]) {
            free(buf);
            return NO;
        }
        if (![sink writeChar:'\n']) {
            free(buf);
            return NO;
        }
    }

    free(buf);
    return YES;
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        uint64_t n = 4;
        NSString *outPath = @"system_safe.txt";

        if (argc >= 2) {
            char *endp = NULL;
            unsigned long long parsed = strtoull(argv[1], &endp, 10);
            if (endp && *endp == '\0') {
                n = (uint64_t)parsed;
            } else {
                fprintf(stderr, "Invalid N: %s\n", argv[1]);
                return 2;
            }
        }

        if (argc >= 3) {
            outPath = [NSString stringWithUTF8String:argv[2]];
        }

        FileSink *sink = [[FileSink alloc] initWithPath:outPath];
        if (!sink) {
            perror("Error opening file");
            return 1;
        }

        BOOL ok = generate_permutations(n, sink);
        [sink close];

        return ok ? 0 : 1;
    }
}

```

<a id="file-20"></a>
### [20] `Pascal.txt`

- **Bytes:** `4761`
- **Type:** `text`

```text
{ Pascal.txt
  Converted from the x86-64 assembly listing in assembly.txt into equivalent Pascal (FreePascal / Delphi-style) code.

  Behavior matches the assembly:

  - ALPHABET is 64 bytes: a-z, A-Z, 0-9, space, LF (#10).
  - safe_uint64_power(64, N) detects overflow in 64-bit unsigned arithmetic (QWord).
  - generate_permutations(N, sink) enumerates i = 0 .. 64^N-1 and forms an N-byte token
    using base-64 digits (low 6 bits) from right to left, then writes the token and appends LF.
  - main uses N = 4 and output file "system_safe.txt".

  Build (FreePascal):
    fpc -O3 -Mobjfpc main.pas

  Run:
    ./main

  Output:
    system_safe.txt

  NOTE: Because ALPHABET itself contains LF as its 64th character AND we also append LF after each token,
  some tokens contain embedded newlines. This is intentional and matches the assembly output.
}

program system_safe;

{$mode objfpc}{$H+}

uses
  SysUtils, Classes;

const
  MaxN = 50;

  // 64-byte alphabet exactly as in the assembly:
  // "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ01234567" + "89 \n"
  AlphabetStr: AnsiString =
    'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ' + #10;

type
  TWriteFn = function(ctx: Pointer; bytes: PAnsiChar; len: QWord): Boolean; cdecl;
  TWriteCharFn = function(ctx: Pointer; c: AnsiChar): Boolean; cdecl;

  POutputSink = ^TOutputSink;
  TOutputSink = record
    ctx: Pointer;         // in the assembly: FILE*
    write: TWriteFn;      // file_sink_write
    writeChar: TWriteCharFn; // file_sink_write_char
  end;

function SafeUInt64Power(const base, exp: QWord; outValue: PQWord): Boolean;
var
  i: QWord;
  r: QWord;
begin
  if outValue = nil then Exit(False);

  r := 1;
  for i := 0 to exp - 1 do
  begin
    // Overflow detection: r * base must fit in QWord.
    if (base <> 0) and (r > High(QWord) div base) then
      Exit(False);
    r := r * base;
  end;

  outValue^ := r;
  Result := True;
end;

function FileSinkWrite(ctx: Pointer; bytes: PAnsiChar; len: QWord): Boolean; cdecl;
var
  s: TStream;
  want, wrote: SizeInt;
begin
  Result := False;
  if (ctx = nil) or (bytes = nil) then Exit;

  s := TStream(ctx);

  // In this program len is small (<= 50), but we keep it safe.
  if len > QWord(High(SizeInt)) then Exit;
  want := SizeInt(len);

  wrote := s.Write(bytes^, want);
  Result := (wrote = want);
end;

function FileSinkWriteChar(ctx: Pointer; c: AnsiChar): Boolean; cdecl;
var
  s: TStream;
  wrote: SizeInt;
begin
  Result := False;
  if ctx = nil then Exit;
  s := TStream(ctx);

  wrote := s.Write(c, 1);
  Result := (wrote = 1);
end;

function FileSinkInit(sink: POutputSink; const path: AnsiString): Boolean;
var
  fs: TBufferedFileStream;
begin
  Result := False;
  if sink = nil then Exit;

  try
    // Equivalent to fopen(path, "w"): create/truncate for writing.
    fs := TBufferedFileStream.Create(path, fmCreate);
  except
    Exit(False);
  end;

  sink^.ctx := Pointer(fs);
  sink^.write := @FileSinkWrite;
  sink^.writeChar := @FileSinkWriteChar;
  Result := True;
end;

procedure FileSinkClose(sink: POutputSink);
var
  s: TObject;
begin
  if (sink = nil) or (sink^.ctx = nil) then Exit;

  s := TObject(sink^.ctx);
  sink^.ctx := nil;
  sink^.write := nil;
  sink^.writeChar := nil;

  // Close by freeing the stream.
  s.Free;
end;

function GeneratePermutations(const n: QWord; sink: POutputSink): Boolean;
var
  limit: QWord;
  buf: array[0..MaxN-1] of AnsiChar;
  i, v: QWord;
  pos: Integer;
  idx: QWord;
begin
  Result := False;

  if (sink = nil) or (sink^.ctx = nil) or (not Assigned(sink^.write)) or (not Assigned(sink^.writeChar)) then
    Exit(False);

  if (Length(AlphabetStr) <> 64) then
    Exit(False);

  if n > MaxN then
    Exit(False);

  if not SafeUInt64Power(64, n, @limit) then
    Exit(False);

  // Enumerate all 64^N tokens.
  for i := 0 to limit - 1 do
  begin
    v := i;

    // Fill token from right to left (pos = n-1 .. 0).
    for pos := Integer(n) - 1 downto 0 do
    begin
      idx := v and 63; // 0..63
      buf[pos] := AlphabetStr[Integer(idx) + 1]; // Pascal strings are 1-based
      v := v shr 6;
    end;

    // Write exactly N bytes, then a newline.
    if (n > 0) then
      if not sink^.write(sink^.ctx, @buf[0], n) then Exit(False);

    if not sink^.writeChar(sink^.ctx, #10) then Exit(False);
  end;

  Result := True;
end;

var
  Sink: TOutputSink;
  Ok: Boolean;
begin
  FillChar(Sink, SizeOf(Sink), 0);

  // main: N = 4, output path "system_safe.txt"
  if not FileSinkInit(@Sink, 'system_safe.txt') then
  begin
    Writeln(ErrOutput, 'Error opening file: ', SysErrorMessage(GetLastOSError));
    Halt(1);
  end;

  Ok := GeneratePermutations(4, @Sink);
  FileSinkClose(@Sink);

  if Ok then
    Halt(0)
  else
    Halt(1);
end.

```

<a id="file-21"></a>
### [21] `Rust.txt`

- **Bytes:** `3110`
- **Type:** `text`

```text
// Rust.txt
// Converted from assembly.txt (x86-64) into equivalent Rust source.
//
// Behavior (matches the assembly):
// - Alphabet is 64 bytes: a-z, A-Z, 0-9, space, newline.
// - Computes limit = 64^N with overflow detection (UInt64).
// - For each i in [0, limit), forms an N-byte token using base-64 digits:
//     token[pos] = ALPHABET[i & 63]; i >>= 6; filling from right to left.
// - Writes token bytes (exactly N bytes) then writes '\n'.
// - main uses N = 4 and output path "system_safe.txt".
//
// Build:
//   rustc -O main.rs
//
// Run:
//   ./main
//
// Output:
//   system_safe.txt
//
// Note: Because the alphabet itself includes '\n' as the 64th character AND we also append '\n',
// some tokens contain embedded newlines, so the output file will not be strictly "one token per line"
// when those embedded newlines occur (this is intentional and matches the assembly).

use std::fs::File;
use std::io::{self, BufWriter, Write};

const ALPHABET: &[u8; 64] =
    b"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \n";

fn safe_u64_power(base: u64, exp: u64) -> Option<u64> {
    let mut out: u64 = 1;
    for _ in 0..exp {
        out = out.checked_mul(base)?;
    }
    Some(out)
}

trait OutputSink {
    fn write_bytes(&mut self, bytes: &[u8]) -> io::Result<()>;
    fn write_char(&mut self, c: u8) -> io::Result<()>;
}

impl<W: Write> OutputSink for W {
    fn write_bytes(&mut self, bytes: &[u8]) -> io::Result<()> {
        self.write_all(bytes)
    }
    fn write_char(&mut self, c: u8) -> io::Result<()> {
        self.write_all(&[c])
    }
}

fn generate_permutations(n: u64, sink: &mut dyn OutputSink) -> io::Result<bool> {
    let limit = match safe_u64_power(64, n) {
        Some(v) => v,
        None => return Ok(false),
    };

    // The assembly uses a fixed stack buffer and writes exactly N bytes each iteration.
    // Here we allocate a Vec of length N.
    let n_usize: usize = match n.try_into() {
        Ok(v) => v,
        Err(_) => return Ok(false),
    };
    let mut buf = vec![0u8; n_usize];

    for i in 0..limit {
        let mut v = i;
        for pos in (0..n_usize).rev() {
            let idx = (v & 63) as usize;
            buf[pos] = ALPHABET[idx];
            v >>= 6;
        }

        // Write token bytes, then '\n' (10).
        if let Err(_) = sink.write_bytes(&buf) {
            return Ok(false);
        }
        if let Err(_) = sink.write_char(b'\n') {
            return Ok(false);
        }
    }

    Ok(true)
}

fn main() {
    let n: u64 = 4;
    let out_path = "system_safe.txt";

    let file = match File::create(out_path) {
        Ok(f) => f,
        Err(e) => {
            eprintln!("Error opening file: {}", e);
            std::process::exit(1);
        }
    };

    let mut writer = BufWriter::new(file);

    let ok = match generate_permutations(n, &mut writer) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("Write error: {}", e);
            false
        }
    };

    // Ensure all buffered data is flushed.
    let _ = writer.flush();

    std::process::exit(if ok { 0 } else { 1 });
}

```

<a id="file-22"></a>
### [22] `Swift.txt`

- **Bytes:** `3269`
- **Type:** `text`

```text
// Swift.txt
// Converted from assembly.txt (x86-64) into equivalent Swift source.
//
// What it does:
// - Defines a 64-character alphabet: a-z, A-Z, 0-9, space, newline.
// - Computes limit = 64^N safely in UInt64 (overflow-checked).
// - For each i in [0, limit), emits an N-byte token by treating i as base-64 digits
//   (using the low 6 bits per digit, from right to left).
// - Writes each token followed by '\n' to "system_safe.txt".
// - In the original assembly, N is fixed to 4.
//
// Build (macOS):
//   swiftc -O main.swift -o system_safe
//
// Run:
//   ./system_safe
//
// Output:
//   system_safe.txt

import Foundation
import Darwin

private let alphabet: [UInt8] = Array("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \n".utf8)
// Expected length: 64
private let alphabetMask: UInt64 = 63

private func safeUInt64Power(base: UInt64, exp: UInt64) -> (ok: Bool, value: UInt64) {
    var result: UInt64 = 1
    if exp == 0 { return (true, 1) }

    for _ in 0..<exp {
        let (p, overflow) = result.multipliedReportingOverflow(by: base)
        if overflow { return (false, 0) }
        result = p
    }
    return (true, result)
}

private protocol OutputSink: AnyObject {
    func write(bytes: UnsafeRawPointer, count: Int) -> Bool
    func writeByte(_ b: UInt8) -> Bool
    func close()
}

private final class FileSink: OutputSink {
    private var fp: UnsafeMutablePointer<FILE>?

    init?(path: String) {
        self.fp = fopen(path, "w")
        if self.fp == nil { return nil }
    }

    func write(bytes: UnsafeRawPointer, count: Int) -> Bool {
        guard let fp else { return false }
        let wrote = fwrite(bytes, 1, count, fp)
        return wrote == count
    }

    func writeByte(_ b: UInt8) -> Bool {
        guard let fp else { return false }
        return fputc(Int32(b), fp) != EOF
    }

    func close() {
        if let fp {
            fclose(fp)
            self.fp = nil
        }
    }

    deinit {
        close()
    }
}

private func generatePermutations(n: UInt64, sink: OutputSink) -> Bool {
    guard alphabet.count == 64 else { return false }

    let pow = safeUInt64Power(base: 64, exp: n)
    guard pow.ok else { return false }
    let limit = pow.value

    // Buffer holds exactly N bytes (no terminator).
    var buffer = [UInt8](repeating: 0, count: Int(n))

    for i in 0..<limit {
        var v = i
        for pos in stride(from: Int(n) - 1, through: 0, by: -1) {
            let idx = Int(v & alphabetMask)
            buffer[pos] = alphabet[idx]
            v >>= 6
        }

        let okWriteToken = buffer.withUnsafeBytes { rawBuf -> Bool in
            guard let baseAddr = rawBuf.baseAddress else { return false }
            return sink.write(bytes: baseAddr, count: buffer.count)
        }
        if !okWriteToken { return false }
        if !sink.writeByte(10) { return false } // '\n'
    }

    return true
}

@main
struct Program {
    static func main() {
        let n: UInt64 = 4
        let outPath = "system_safe.txt"

        guard let sink = FileSink(path: outPath) else {
            perror("Error opening file")
            exit(1)
        }

        let ok = generatePermutations(n: n, sink: sink)
        sink.close()

        exit(ok ? 0 : 1)
    }
}

```

<a id="file-23"></a>
### [23] `Zig.txt`

- **Bytes:** `3864`
- **Type:** `text`

```text
// Zig.txt
// Converted from the x86-64 assembly in assembly.txt into equivalent Zig code.
//
// Behavior matches the assembly:
// - ALPHABET is 64 bytes: a-z, A-Z, 0-9, space, newline.
// - safe_uint64_power(64, N) detects overflow in u64.
// - generate_permutations(N, &sink) emits 64^N tokens, each N bytes, derived from i in base-64
//   (low 6 bits per digit, filled from right to left), and then appends '\n'.
// - main uses N = 4 and output path "system_safe.txt".
//
// Build (needs libc for stdio):
//   zig build-exe main.zig -O ReleaseFast -lc
//
// Run:
//   ./main
//
// Output:
//   system_safe.txt
//
// NOTE: Because ALPHABET includes '\n' as its last character, some generated tokens contain embedded
// newlines in addition to the trailing '\n'. This is intentional and matches the assembly output.

const std = @import("std");
const c = @cImport({
    @cInclude("stdio.h");
});

const ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \n";

comptime {
    if (ALPHABET.len != 64) @compileError("ALPHABET must be exactly 64 bytes");
}

const OutputSink = extern struct {
    // In the assembly this is a `void*` context; for the file sink it's a FILE*.
    ctx: ?*c.FILE = null,

    // bool write(void* ctx, const char* bytes, unsigned long len)
    write: ?*const fn (?*c.FILE, [*]const u8, usize) callconv(.C) bool = null,

    // bool write_char(void* ctx, char c)
    write_char: ?*const fn (?*c.FILE, u8) callconv(.C) bool = null,
};

fn safe_uint64_power(base: u64, exp: u64, out: *u64) bool {
    var result: u64 = 1;
    var i: u64 = 0;
    while (i < exp) : (i += 1) {
        result = std.math.mul(u64, result, base) catch return false;
    }
    out.* = result;
    return true;
}

fn file_sink_write(ctx: ?*c.FILE, bytes: [*]const u8, len: usize) callconv(.C) bool {
    if (ctx == null) return false;
    // fwrite(ptr, size=1, nmemb=len, stream)
    const wrote = c.fwrite(bytes, 1, len, ctx.?);
    return wrote == len;
}

fn file_sink_write_char(ctx: ?*c.FILE, ch: u8) callconv(.C) bool {
    if (ctx == null) return false;
    const rc = c.fputc(@as(c_int, ch), ctx.?);
    return rc != -1;
}

fn file_sink_init(sink: *OutputSink, path: [*:0]const u8) bool {
    const fp = c.fopen(path, "w");
    if (fp == null) return false;

    sink.ctx = fp;
    sink.write = file_sink_write;
    sink.write_char = file_sink_write_char;
    return true;
}

fn file_sink_close(sink: *OutputSink) void {
    if (sink.ctx) |fp| {
        _ = c.fclose(fp);
        sink.ctx = null;
    }
}

fn generate_permutations(n: u64, sink: *OutputSink) bool {
    var limit: u64 = 0;
    if (!safe_uint64_power(64, n, &limit)) return false;

    // The assembly uses a fixed stack buffer at [rbp-50]. We mirror that with a max of 50 bytes.
    var buf: [50]u8 = undefined;
    const n_usize: usize = @intCast(n);
    if (n_usize > buf.len) return false;

    const token = buf[0..n_usize];

    const write_fn = sink.write orelse return false;
    const write_char_fn = sink.write_char orelse return false;

    var i: u64 = 0;
    while (i < limit) : (i += 1) {
        var v: u64 = i;

        // Fill from right to left
        var pos: usize = n_usize;
        while (pos > 0) {
            pos -= 1;
            const idx: usize = @intCast(v & 63);
            token[pos] = ALPHABET[idx];
            v >>= 6;
        }

        if (!write_fn(sink.ctx, token.ptr, token.len)) return false;
        if (!write_char_fn(sink.ctx, '\n')) return false;
    }

    return true;
}

pub fn main() void {
    var sink: OutputSink = .{};
    const out_path: [*:0]const u8 = "system_safe.txt";

    if (!file_sink_init(&sink, out_path)) {
        c.perror("Error opening file");
        std.process.exit(1);
    }

    const ok = generate_permutations(4, &sink);
    file_sink_close(&sink);

    std.process.exit(if (ok) 0 else 1);
}

```

